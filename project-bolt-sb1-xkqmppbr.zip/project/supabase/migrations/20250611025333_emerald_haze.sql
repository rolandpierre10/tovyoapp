/*
  # Créer la table des sites générés par l'IA

  1. Nouvelle table
    - `generated_sites` pour stocker les sites créés par l'IA
    - Colonnes pour l'ID, utilisateur, nom, URL, contenu, statut, dates

  2. Sécurité
    - RLS activé
    - Politiques pour que les utilisateurs ne voient que leurs sites
    - Politiques admin pour voir tous les sites
*/

-- Créer la table des sites générés
CREATE TABLE IF NOT EXISTS generated_sites (
  id text PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  url text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'ready' CHECK (status IN ('generating', 'ready', 'error')),
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Activer RLS
ALTER TABLE generated_sites ENABLE ROW LEVEL SECURITY;

-- Index pour les performances
CREATE INDEX IF NOT EXISTS generated_sites_user_id_idx ON generated_sites(user_id);
CREATE INDEX IF NOT EXISTS generated_sites_created_at_idx ON generated_sites(created_at DESC);
CREATE INDEX IF NOT EXISTS generated_sites_status_idx ON generated_sites(status);

-- Politique pour que les utilisateurs voient leurs propres sites
CREATE POLICY "Users can view their own generated sites" ON generated_sites
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Politique pour que les utilisateurs puissent créer leurs sites
CREATE POLICY "Users can create their own generated sites" ON generated_sites
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Politique pour que les utilisateurs puissent modifier leurs sites
CREATE POLICY "Users can update their own generated sites" ON generated_sites
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Politique pour que les utilisateurs puissent supprimer leurs sites
CREATE POLICY "Users can delete their own generated sites" ON generated_sites
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Politiques admin pour voir tous les sites
CREATE POLICY "Admins can view all generated sites" ON generated_sites
  FOR SELECT
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique admin pour modifier tous les sites
CREATE POLICY "Admins can update all generated sites" ON generated_sites
  FOR UPDATE
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique admin pour supprimer tous les sites
CREATE POLICY "Admins can delete all generated sites" ON generated_sites
  FOR DELETE
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Fonction pour mettre à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION update_generated_sites_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger pour mettre à jour updated_at automatiquement
CREATE TRIGGER update_generated_sites_updated_at
  BEFORE UPDATE ON generated_sites
  FOR EACH ROW
  EXECUTE FUNCTION update_generated_sites_updated_at();