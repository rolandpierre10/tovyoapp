/*
  # Créer un utilisateur administrateur

  1. Création du profil administrateur
    - Utilisateur avec email admin@tovyoapp.com
    - Rôle administrateur
    - Permissions spéciales

  2. Sécurité
    - RLS activé
    - Politiques pour l'accès admin
*/

-- Insérer le profil administrateur (l'utilisateur doit d'abord être créé via Supabase Auth)
INSERT INTO profiles (id, email, full_name, role, created_at, updated_at)
VALUES (
  '00000000-0000-0000-0000-000000000000', -- ID temporaire, sera remplacé par l'ID réel de Supabase Auth
  'admin@tovyoapp.com',
  'Administrateur TovyoApp',
  'admin',
  now(),
  now()
) ON CONFLICT (email) DO UPDATE SET
  full_name = EXCLUDED.full_name,
  role = EXCLUDED.role,
  updated_at = now();

-- Politique pour permettre aux admins de voir tous les profils
CREATE POLICY "Les admins peuvent voir tous les profils" ON profiles
  FOR SELECT
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique pour permettre aux admins de modifier tous les profils
CREATE POLICY "Les admins peuvent modifier tous les profils" ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  )
  WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique pour permettre aux admins de supprimer des profils
CREATE POLICY "Les admins peuvent supprimer des profils" ON profiles
  FOR DELETE
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique pour permettre aux admins de voir tous les clients Stripe
CREATE POLICY "Les admins peuvent voir tous les clients Stripe" ON stripe_customers
  FOR SELECT
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique pour permettre aux admins de voir tous les abonnements
CREATE POLICY "Les admins peuvent voir tous les abonnements" ON stripe_subscriptions
  FOR SELECT
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

-- Politique pour permettre aux admins de voir toutes les commandes
CREATE POLICY "Les admins peuvent voir toutes les commandes" ON stripe_orders
  FOR SELECT
  TO authenticated
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );