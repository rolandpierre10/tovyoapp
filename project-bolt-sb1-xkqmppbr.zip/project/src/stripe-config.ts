export interface StripeProduct {
  id: string;
  priceId: string;
  name: string;
  description: string;
  price: string;
  currency: string;
  mode: 'payment' | 'subscription';
  popular?: boolean;
  features: string[];
}

export const stripeProducts: StripeProduct[] = [
  {
    id: 'prod_SSOdE4IBEnFtbi',
    priceId: 'price_1RXTq4DcUBznaKKpaYSyGQG3',
    name: 'Starter',
    description: 'Parfait pour débuter',
    price: '19.99',
    currency: 'USD',
    mode: 'subscription',
    popular: false,
    features: [
      '1 site web professionnel',
      'Hébergement sécurisé inclus',
      'Support par email',
      'SSL gratuit',
      'Templates modernes'
    ]
  },
  {
    id: 'prod_SSObATo71Qc6nt',
    priceId: 'price_1RXTohDcUBznaKKpLkvOQyYB',
    name: 'Pro',
    description: 'Pour les entrepreneurs ambitieux',
    price: '39.99',
    currency: 'USD',
    mode: 'subscription',
    popular: true,
    features: [
      'Jusqu\'à 3 sites web',
      'Support prioritaire 24/7',
      'Mises à jour en temps réel',
      'Analytics avancées',
      'Templates premium',
      'Domaine personnalisé'
    ]
  }
];

export const getProductByPriceId = (priceId: string): StripeProduct | undefined => {
  return stripeProducts.find(product => product.priceId === priceId);
};

export const getProductById = (id: string): StripeProduct | undefined => {
  return stripeProducts.find(product => product.id === id);
};