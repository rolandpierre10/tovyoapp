import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let supabase: any;

// Check if environment variables are properly configured
if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase environment variables not configured. Using demo mode.');
  
  // Create a mock client for demo purposes
  const mockClient = {
    auth: {
      getSession: () => Promise.resolve({ data: { session: null }, error: null }),
      getUser: () => Promise.resolve({ data: { user: null }, error: null }),
      signInWithPassword: ({ email, password }: { email: string; password: string }) => {
        // Demo login logic
        if (email === 'admin@tovyoapp.com' && password === 'admin123') {
          const mockUser = {
            id: 'admin-demo-id',
            email: 'admin@tovyoapp.com',
            user_metadata: { full_name: 'Administrateur' },
            created_at: new Date().toISOString()
          };
          const mockSession = {
            user: mockUser,
            access_token: 'demo-token',
            refresh_token: 'demo-refresh'
          };
          return Promise.resolve({ data: { user: mockUser, session: mockSession }, error: null });
        } else if (email === 'demo@example.com' && password === 'demo123') {
          const mockUser = {
            id: 'demo-user-id',
            email: 'demo@example.com',
            user_metadata: { full_name: 'Utilisateur Demo' },
            created_at: new Date().toISOString()
          };
          const mockSession = {
            user: mockUser,
            access_token: 'demo-token',
            refresh_token: 'demo-refresh'
          };
          return Promise.resolve({ data: { user: mockUser, session: mockSession }, error: null });
        } else {
          return Promise.resolve({ 
            data: { user: null, session: null }, 
            error: { message: 'Invalid login credentials' } 
          });
        }
      },
      signUp: ({ email, password, options }: any) => {
        // Demo signup logic
        const mockUser = {
          id: 'new-demo-user-' + Date.now(),
          email: email,
          user_metadata: options?.data || {},
          created_at: new Date().toISOString()
        };
        const mockSession = {
          user: mockUser,
          access_token: 'demo-token',
          refresh_token: 'demo-refresh'
        };
        return Promise.resolve({ data: { user: mockUser, session: mockSession }, error: null });
      },
      signOut: () => Promise.resolve({ error: null }),
      onAuthStateChange: (callback: Function) => {
        // Mock subscription
        return {
          data: {
            subscription: {
              unsubscribe: () => {}
            }
          }
        };
      }
    },
    from: (table: string) => ({
      select: () => ({
        eq: () => ({
          single: () => Promise.resolve({ data: null, error: { code: 'PGRST116' } })
        })
      })
    })
  };

  supabase = mockClient;
} else {
  // Check if the URL is still a placeholder
  if (supabaseUrl.includes('your-actual-supabase-url-here') || supabaseUrl === 'your_supabase_project_url') {
    console.warn('Please replace the placeholder Supabase URL in your .env file');
    throw new Error('Please replace the placeholder Supabase URL in your .env file with your actual Supabase project URL (e.g., https://your-project-id.supabase.co)');
  }

  // Check if the anon key is still a placeholder
  if (supabaseAnonKey.includes('your-actual-supabase-anon-key-here') || supabaseAnonKey === 'your_supabase_anon_key') {
    console.warn('Please replace the placeholder Supabase anon key in your .env file');
    throw new Error('Please replace the placeholder Supabase anon key in your .env file with your actual Supabase anon key');
  }

  // Validate URL format
  try {
    new URL(supabaseUrl);
  } catch (error) {
    console.error(`Invalid Supabase URL format: ${supabaseUrl}`);
    throw new Error(`Invalid Supabase URL format: ${supabaseUrl}. Please ensure it follows the format: https://your-project-id.supabase.co`);
  }

  console.log('Supabase configuration:', {
    url: supabaseUrl,
    hasAnonKey: !!supabaseAnonKey
  });

  supabase = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true
    }
  });
}

// Types pour TypeScript
export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string | null;
          full_name: string | null;
          avatar_url: string | null;
          role: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email?: string | null;
          full_name?: string | null;
          avatar_url?: string | null;
          role?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string | null;
          full_name?: string | null;
          avatar_url?: string | null;
          role?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      stripe_customers: {
        Row: {
          id: number;
          user_id: string;
          customer_id: string;
          created_at: string | null;
          updated_at: string | null;
          deleted_at: string | null;
        };
        Insert: {
          user_id: string;
          customer_id: string;
          created_at?: string | null;
          updated_at?: string | null;
          deleted_at?: string | null;
        };
        Update: {
          user_id?: string;
          customer_id?: string;
          created_at?: string | null;
          updated_at?: string | null;
          deleted_at?: string | null;
        };
      };
      stripe_subscriptions: {
        Row: {
          id: number;
          customer_id: string;
          subscription_id: string | null;
          price_id: string | null;
          current_period_start: number | null;
          current_period_end: number | null;
          cancel_at_period_end: boolean | null;
          payment_method_brand: string | null;
          payment_method_last4: string | null;
          status: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          created_at: string | null;
          updated_at: string | null;
          deleted_at: string | null;
        };
        Insert: {
          customer_id: string;
          subscription_id?: string | null;
          price_id?: string | null;
          current_period_start?: number | null;
          current_period_end?: number | null;
          cancel_at_period_end?: boolean | null;
          payment_method_brand?: string | null;
          payment_method_last4?: string | null;
          status: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          created_at?: string | null;
          updated_at?: string | null;
          deleted_at?: string | null;
        };
        Update: {
          customer_id?: string;
          subscription_id?: string | null;
          price_id?: string | null;
          current_period_start?: number | null;
          current_period_end?: number | null;
          cancel_at_period_end?: boolean | null;
          payment_method_brand?: string | null;
          payment_method_last4?: string | null;
          status?: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused';
          created_at?: string | null;
          updated_at?: string | null;
          deleted_at?: string | null;
        };
      };
    };
    Views: {
      stripe_user_subscriptions: {
        Row: {
          customer_id: string | null;
          subscription_id: string | null;
          subscription_status: 'not_started' | 'incomplete' | 'incomplete_expired' | 'trialing' | 'active' | 'past_due' | 'canceled' | 'unpaid' | 'paused' | null;
          price_id: string | null;
          current_period_start: number | null;
          current_period_end: number | null;
          cancel_at_period_end: boolean | null;
          payment_method_brand: string | null;
          payment_method_last4: string | null;
        };
      };
    };
  };
}

export { supabase };