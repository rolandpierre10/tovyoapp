import { supabase } from './supabase';

export interface SiteGenerationRequest {
  name: string;
  email: string;
  businessType: string;
  description: string;
  style: string;
  colors: string;
  userId: string;
}

export interface GeneratedSite {
  id: string;
  name: string;
  url: string;
  content: {
    title: string;
    subtitle: string;
    sections: SiteSection[];
    colors: ColorScheme;
    fonts: FontScheme;
  };
  status: 'generating' | 'ready' | 'error';
  createdAt: string;
}

export interface SiteSection {
  id: string;
  type: 'hero' | 'about' | 'services' | 'portfolio' | 'contact' | 'menu' | 'testimonials';
  title: string;
  content: any;
  order: number;
}

export interface ColorScheme {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
}

export interface FontScheme {
  heading: string;
  body: string;
}

// Templates de contenu par type d'activité
const businessTemplates = {
  'Restaurant / Bar': {
    sections: ['hero', 'about', 'menu', 'contact'],
    defaultContent: {
      hero: {
        title: 'Bienvenue chez {name}',
        subtitle: 'Une expérience culinaire authentique vous attend',
        cta: 'Réserver une table'
      },
      about: {
        title: 'Notre Histoire',
        content: 'Depuis notre ouverture, nous nous engageons à offrir une cuisine de qualité dans une atmosphère chaleureuse et conviviale.'
      },
      menu: {
        title: 'Notre Menu',
        categories: ['Entrées', 'Plats', 'Desserts', 'Boissons']
      },
      contact: {
        title: 'Nous Contacter',
        address: '123 Rue de la Gastronomie, 75001 Paris',
        phone: '01 23 45 67 89',
        hours: 'Mar-Dim: 12h-14h30, 19h-22h30'
      }
    }
  },
  'E-commerce / Boutique': {
    sections: ['hero', 'about', 'services', 'contact'],
    defaultContent: {
      hero: {
        title: '{name}',
        subtitle: 'Découvrez notre sélection de produits de qualité',
        cta: 'Voir nos produits'
      },
      about: {
        title: 'À Propos',
        content: 'Nous sélectionnons avec soin les meilleurs produits pour vous offrir une expérience d\'achat exceptionnelle.'
      },
      services: {
        title: 'Nos Services',
        items: ['Livraison rapide', 'Service client 24/7', 'Retours gratuits', 'Garantie qualité']
      }
    }
  },
  'Services professionnels': {
    sections: ['hero', 'about', 'services', 'contact'],
    defaultContent: {
      hero: {
        title: '{name}',
        subtitle: 'Des solutions professionnelles adaptées à vos besoins',
        cta: 'Nous contacter'
      },
      about: {
        title: 'Notre Expertise',
        content: 'Fort de notre expérience, nous accompagnons nos clients dans la réalisation de leurs projets avec professionnalisme et efficacité.'
      },
      services: {
        title: 'Nos Services',
        items: ['Conseil personnalisé', 'Solutions sur mesure', 'Suivi de projet', 'Support technique']
      }
    }
  },
  'Créateur / Artiste': {
    sections: ['hero', 'about', 'portfolio', 'contact'],
    defaultContent: {
      hero: {
        title: '{name}',
        subtitle: 'Créateur passionné, je donne vie à vos idées',
        cta: 'Voir mon portfolio'
      },
      about: {
        title: 'Mon Univers',
        content: 'Passionné par la création, je mets mon talent et ma créativité au service de vos projets les plus ambitieux.'
      },
      portfolio: {
        title: 'Mes Créations',
        categories: ['Récent', 'Projets', 'Collaborations']
      }
    }
  },
  'Consultant / Coach': {
    sections: ['hero', 'about', 'services', 'testimonials', 'contact'],
    defaultContent: {
      hero: {
        title: '{name}',
        subtitle: 'Accompagnement personnalisé pour atteindre vos objectifs',
        cta: 'Prendre rendez-vous'
      },
      about: {
        title: 'Mon Approche',
        content: 'Je vous accompagne dans votre développement personnel et professionnel avec une méthode éprouvée et bienveillante.'
      },
      services: {
        title: 'Mes Services',
        items: ['Coaching individuel', 'Formations', 'Ateliers', 'Suivi personnalisé']
      }
    }
  }
};

// Schémas de couleurs par style
const colorSchemes = {
  blue: {
    primary: '#2563eb',
    secondary: '#3b82f6',
    accent: '#1d4ed8',
    background: '#f8fafc',
    text: '#1e293b'
  },
  green: {
    primary: '#059669',
    secondary: '#10b981',
    accent: '#047857',
    background: '#f0fdf4',
    text: '#1f2937'
  },
  purple: {
    primary: '#7c3aed',
    secondary: '#8b5cf6',
    accent: '#6d28d9',
    background: '#faf5ff',
    text: '#1f2937'
  },
  orange: {
    primary: '#ea580c',
    secondary: '#f97316',
    accent: '#c2410c',
    background: '#fff7ed',
    text: '#1f2937'
  }
};

// Schémas de polices par style
const fontSchemes = {
  modern: {
    heading: 'Inter, system-ui, sans-serif',
    body: 'Inter, system-ui, sans-serif'
  },
  creative: {
    heading: 'Playfair Display, serif',
    body: 'Source Sans Pro, sans-serif'
  },
  corporate: {
    heading: 'Roboto, sans-serif',
    body: 'Open Sans, sans-serif'
  },
  playful: {
    heading: 'Poppins, sans-serif',
    body: 'Nunito, sans-serif'
  }
};

export class AIWebsiteGenerator {
  private static instance: AIWebsiteGenerator;

  public static getInstance(): AIWebsiteGenerator {
    if (!AIWebsiteGenerator.instance) {
      AIWebsiteGenerator.instance = new AIWebsiteGenerator();
    }
    return AIWebsiteGenerator.instance;
  }

  async generateWebsite(request: SiteGenerationRequest): Promise<GeneratedSite> {
    try {
      console.log('🤖 IA: Début de la génération du site pour', request.name);
      
      // Étape 1: Analyser les préférences utilisateur
      await this.simulateProcessingStep('Analyse des préférences utilisateur...', 800);
      
      // Étape 2: Sélectionner le template approprié
      const template = this.selectTemplate(request.businessType);
      await this.simulateProcessingStep('Sélection du template optimal...', 600);
      
      // Étape 3: Générer le contenu personnalisé
      const content = await this.generateContent(request, template);
      await this.simulateProcessingStep('Génération du contenu personnalisé...', 1000);
      
      // Étape 4: Appliquer le style et les couleurs
      const colors = colorSchemes[request.colors as keyof typeof colorSchemes] || colorSchemes.blue;
      const fonts = fontSchemes[request.style as keyof typeof fontSchemes] || fontSchemes.modern;
      await this.simulateProcessingStep('Application du design et des couleurs...', 700);
      
      // Étape 5: Optimisation mobile et SEO
      await this.simulateProcessingStep('Optimisation mobile et SEO...', 900);
      
      // Étape 6: Configuration de l'hébergement
      await this.simulateProcessingStep('Configuration de l\'hébergement sécurisé...', 500);
      
      const siteId = this.generateSiteId();
      const siteUrl = this.generateSiteUrl(request.name, siteId);
      
      const generatedSite: GeneratedSite = {
        id: siteId,
        name: request.name,
        url: siteUrl,
        content: {
          title: content.title,
          subtitle: content.subtitle,
          sections: content.sections,
          colors,
          fonts
        },
        status: 'ready',
        createdAt: new Date().toISOString()
      };
      
      // Sauvegarder le site généré
      await this.saveSiteToDatabase(generatedSite, request.userId);
      
      // Envoyer l'email de notification
      await this.sendNotificationEmail(request.email, generatedSite);
      
      console.log('✅ IA: Site généré avec succès:', siteUrl);
      return generatedSite;
      
    } catch (error) {
      console.error('❌ IA: Erreur lors de la génération:', error);
      throw new Error('Erreur lors de la génération du site. Veuillez réessayer.');
    }
  }

  private selectTemplate(businessType: string) {
    return businessTemplates[businessType as keyof typeof businessTemplates] || businessTemplates['Services professionnels'];
  }

  private async generateContent(request: SiteGenerationRequest, template: any) {
    // Personnaliser le contenu basé sur la description de l'utilisateur
    const personalizedContent = this.personalizeContent(template.defaultContent, request);
    
    // Générer les sections
    const sections: SiteSection[] = template.sections.map((sectionType: string, index: number) => ({
      id: `section-${index}`,
      type: sectionType as any,
      title: personalizedContent[sectionType]?.title || sectionType,
      content: personalizedContent[sectionType] || {},
      order: index
    }));

    return {
      title: request.name,
      subtitle: this.generateSubtitle(request),
      sections
    };
  }

  private personalizeContent(defaultContent: any, request: SiteGenerationRequest) {
    const content = JSON.parse(JSON.stringify(defaultContent));
    
    // Remplacer les placeholders
    const replacePlaceholders = (obj: any): any => {
      if (typeof obj === 'string') {
        return obj.replace(/{name}/g, request.name);
      }
      if (typeof obj === 'object' && obj !== null) {
        const result: any = {};
        for (const key in obj) {
          result[key] = replacePlaceholders(obj[key]);
        }
        return result;
      }
      return obj;
    };

    return replacePlaceholders(content);
  }

  private generateSubtitle(request: SiteGenerationRequest): string {
    const subtitles = {
      'Restaurant / Bar': 'Une expérience culinaire authentique vous attend',
      'E-commerce / Boutique': 'Découvrez notre sélection de produits de qualité',
      'Services professionnels': 'Des solutions professionnelles adaptées à vos besoins',
      'Créateur / Artiste': 'Créateur passionné, je donne vie à vos idées',
      'Consultant / Coach': 'Accompagnement personnalisé pour atteindre vos objectifs'
    };

    return subtitles[request.businessType as keyof typeof subtitles] || 'Bienvenue sur notre site web professionnel';
  }

  private generateSiteId(): string {
    return `site-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateSiteUrl(name: string, siteId: string): string {
    const slug = name.toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
    return `https://${slug}-${siteId.split('-')[1]}.tovyoapp.com`;
  }

  private async saveSiteToDatabase(site: GeneratedSite, userId: string) {
    try {
      const { error } = await supabase
        .from('generated_sites')
        .insert({
          id: site.id,
          user_id: userId,
          name: site.name,
          url: site.url,
          content: site.content,
          status: site.status,
          created_at: site.createdAt
        });

      if (error) {
        console.error('Erreur lors de la sauvegarde:', error);
      }
    } catch (error) {
      console.error('Erreur de base de données:', error);
    }
  }

  private async sendNotificationEmail(email: string, site: GeneratedSite) {
    // Simulation d'envoi d'email
    console.log(`📧 Email envoyé à ${email} pour le site ${site.url}`);
    
    // Dans un vrai environnement, vous utiliseriez un service comme SendGrid, Mailgun, etc.
    // Exemple avec une edge function Supabase:
    /*
    try {
      const { error } = await supabase.functions.invoke('send-notification-email', {
        body: {
          to: email,
          siteUrl: site.url,
          siteName: site.name
        }
      });
      
      if (error) {
        console.error('Erreur envoi email:', error);
      }
    } catch (error) {
      console.error('Erreur service email:', error);
    }
    */
  }

  private async simulateProcessingStep(message: string, duration: number) {
    console.log(`🤖 IA: ${message}`);
    await new Promise(resolve => setTimeout(resolve, duration));
  }

  // Méthodes utilitaires pour l'interface utilisateur
  async getSitesByUser(userId: string): Promise<GeneratedSite[]> {
    try {
      const { data, error } = await supabase
        .from('generated_sites')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erreur lors de la récupération des sites:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Erreur de base de données:', error);
      return [];
    }
  }

  async getSiteById(siteId: string): Promise<GeneratedSite | null> {
    try {
      const { data, error } = await supabase
        .from('generated_sites')
        .select('*')
        .eq('id', siteId)
        .single();

      if (error) {
        console.error('Erreur lors de la récupération du site:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Erreur de base de données:', error);
      return null;
    }
  }

  async updateSite(siteId: string, updates: Partial<GeneratedSite>): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('generated_sites')
        .update(updates)
        .eq('id', siteId);

      if (error) {
        console.error('Erreur lors de la mise à jour:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Erreur de base de données:', error);
      return false;
    }
  }

  async deleteSite(siteId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('generated_sites')
        .delete()
        .eq('id', siteId);

      if (error) {
        console.error('Erreur lors de la suppression:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Erreur de base de données:', error);
      return false;
    }
  }
}

// Instance singleton
export const aiGenerator = AIWebsiteGenerator.getInstance();