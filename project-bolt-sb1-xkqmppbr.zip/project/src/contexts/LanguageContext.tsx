import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Types pour les traductions
export interface Translations {
  // Navigation
  nav: {
    home: string;
    login: string;
    register: string;
    dashboard: string;
    logout: string;
    back: string;
  };
  
  // Page d'accueil
  home: {
    title: string;
    subtitle: string;
    newFeature: string;
    heroTitle: string;
    heroSubtitle: string;
    discoverPlans: string;
    startFree: string;
    whyChoose: string;
    whySubtitle: string;
    ultraFast: string;
    ultraFastDesc: string;
    noCode: string;
    noCodeDesc: string;
    professional: string;
    professionalDesc: string;
    choosePlan: string;
    choosePlanSubtitle: string;
    mostPopular: string;
    subscribeNow: string;
    alreadySubscribed: string;
    accessDashboard: string;
    createSite: string;
    footer: string;
  };
  
  // Authentification
  auth: {
    welcomeBack: string;
    connectAccount: string;
    createAccount: string;
    joinTovyo: string;
    email: string;
    password: string;
    confirmPassword: string;
    fullName: string;
    rememberMe: string;
    forgotPassword: string;
    signIn: string;
    signUp: string;
    connecting: string;
    creatingAccount: string;
    noAccount: string;
    hasAccount: string;
    acceptTerms: string;
    termsOfUse: string;
    privacyPolicy: string;
    loginError: string;
    registrationError: string;
    invalidCredentials: string;
    emailNotConfirmed: string;
    tooManyRequests: string;
    userAlreadyExists: string;
    passwordTooShort: string;
    invalidEmailFormat: string;
    unexpectedError: string;
    needHelp: string;
    helpTips: string;
    passwordsDontMatch: string;
    passwordMinLength: string;
  };
  
  // Dashboard
  dashboard: {
    welcome: string;
    manageWebsites: string;
    activeSites: string;
    allOnline: string;
    totalVisits: string;
    thisMonth: string;
    subscription: string;
    loading: string;
    mySites: string;
    newSite: string;
    visits: string;
    updatedAgo: string;
    viewSite: string;
    noSites: string;
    noSitesDesc: string;
    createFirstSite: string;
    subscriptionActivated: string;
    subscriptionActivatedDesc: string;
  };
  
  // Création de site
  createSite: {
    title: string;
    subtitle: string;
    yourName: string;
    yourEmail: string;
    businessType: string;
    selectSector: string;
    describeActivity: string;
    preferredStyle: string;
    mainColors: string;
    createNow: string;
    creating: string;
    readyIn: string;
    businessTypes: {
      restaurant: string;
      ecommerce: string;
      services: string;
      creative: string;
      consultant: string;
      realEstate: string;
      health: string;
      technology: string;
      other: string;
    };
    styles: {
      modern: string;
      creative: string;
      corporate: string;
      playful: string;
    };
    colors: {
      blue: string;
      green: string;
      purple: string;
      orange: string;
    };
  };
  
  // Page de remerciement
  thankYou: {
    title: string;
    subtitle: string;
    estimatedTime: string;
    notification: string;
    maxTime: string;
    secureEmail: string;
    whatsHappening: string;
    analyzingPreferences: string;
    generatingDesign: string;
    optimizingMobile: string;
    configuringHosting: string;
    backHome: string;
    createAnother: string;
    noEmail: string;
    contactUs: string;
  };
  
  // Plans et abonnements
  plans: {
    starter: string;
    starterDesc: string;
    pro: string;
    proDesc: string;
    features: {
      oneSite: string;
      secureHosting: string;
      emailSupport: string;
      freeSSL: string;
      modernTemplates: string;
      threeSites: string;
      prioritySupport: string;
      realTimeUpdates: string;
      advancedAnalytics: string;
      premiumTemplates: string;
      customDomain: string;
    };
  };
  
  // Statuts d'abonnement
  subscriptionStatus: {
    noSubscription: string;
    active: string;
    trialing: string;
    pastDue: string;
    canceled: string;
    incomplete: string;
    notStarted: string;
  };
  
  // Démos
  demo: {
    restaurant: {
      name: string;
      welcome: string;
      subtitle: string;
      menu: string;
      about: string;
      contact: string;
      reserve: string;
      menuOfDay: string;
      menuSubtitle: string;
      starters: string;
      mains: string;
      desserts: string;
      ourStory: string;
      storyText: string;
      experience: string;
      satisfiedClients: string;
      phone: string;
      address: string;
      hours: string;
      reserveNow: string;
      footer: string;
    };
    portfolio: {
      name: string;
      photographer: string;
      subtitle: string;
      portfolio: string;
      about: string;
      services: string;
      contact: string;
      reserve: string;
      viewPortfolio: string;
      contactMe: string;
      weddings: string;
      experience: string;
      satisfied: string;
      myWork: string;
      portfolioSubtitle: string;
      all: string;
      portraits: string;
      nature: string;
      events: string;
      aboutMe: string;
      aboutText: string;
      passion: string;
      since: string;
      myServices: string;
      servicesSubtitle: string;
      weddingsService: string;
      weddingsDesc: string;
      portraitsService: string;
      portraitsDesc: string;
      eventsService: string;
      eventsDesc: string;
      talkProject: string;
      projectDesc: string;
      sendMessage: string;
      footer: string;
    };
  };
  
  // Commun
  common: {
    loading: string;
    error: string;
    success: string;
    cancel: string;
    confirm: string;
    save: string;
    delete: string;
    edit: string;
    close: string;
    next: string;
    previous: string;
    search: string;
    filter: string;
    sort: string;
    createdWith: string;
  };
}

// Langues supportées avec leurs codes ISO et noms natifs
export const supportedLanguages = {
  // Europe
  fr: { name: 'Français', nativeName: 'Français', flag: '🇫🇷' },
  en: { name: 'English', nativeName: 'English', flag: '🇬🇧' },
  es: { name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  de: { name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  it: { name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹' },
  pt: { name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹' },
  nl: { name: 'Dutch', nativeName: 'Nederlands', flag: '🇳🇱' },
  ru: { name: 'Russian', nativeName: 'Русский', flag: '🇷🇺' },
  pl: { name: 'Polish', nativeName: 'Polski', flag: '🇵🇱' },
  sv: { name: 'Swedish', nativeName: 'Svenska', flag: '🇸🇪' },
  da: { name: 'Danish', nativeName: 'Dansk', flag: '🇩🇰' },
  no: { name: 'Norwegian', nativeName: 'Norsk', flag: '🇳🇴' },
  fi: { name: 'Finnish', nativeName: 'Suomi', flag: '🇫🇮' },
  cs: { name: 'Czech', nativeName: 'Čeština', flag: '🇨🇿' },
  sk: { name: 'Slovak', nativeName: 'Slovenčina', flag: '🇸🇰' },
  hu: { name: 'Hungarian', nativeName: 'Magyar', flag: '🇭🇺' },
  ro: { name: 'Romanian', nativeName: 'Română', flag: '🇷🇴' },
  bg: { name: 'Bulgarian', nativeName: 'Български', flag: '🇧🇬' },
  hr: { name: 'Croatian', nativeName: 'Hrvatski', flag: '🇭🇷' },
  sr: { name: 'Serbian', nativeName: 'Српски', flag: '🇷🇸' },
  sl: { name: 'Slovenian', nativeName: 'Slovenščina', flag: '🇸🇮' },
  et: { name: 'Estonian', nativeName: 'Eesti', flag: '🇪🇪' },
  lv: { name: 'Latvian', nativeName: 'Latviešu', flag: '🇱🇻' },
  lt: { name: 'Lithuanian', nativeName: 'Lietuvių', flag: '🇱🇹' },
  el: { name: 'Greek', nativeName: 'Ελληνικά', flag: '🇬🇷' },
  tr: { name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷' },
  
  // Asie
  zh: { name: 'Chinese', nativeName: '中文', flag: '🇨🇳' },
  ja: { name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' },
  ko: { name: 'Korean', nativeName: '한국어', flag: '🇰🇷' },
  hi: { name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  ar: { name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦' },
  th: { name: 'Thai', nativeName: 'ไทย', flag: '🇹🇭' },
  vi: { name: 'Vietnamese', nativeName: 'Tiếng Việt', flag: '🇻🇳' },
  id: { name: 'Indonesian', nativeName: 'Bahasa Indonesia', flag: '🇮🇩' },
  ms: { name: 'Malay', nativeName: 'Bahasa Melayu', flag: '🇲🇾' },
  tl: { name: 'Filipino', nativeName: 'Filipino', flag: '🇵🇭' },
  bn: { name: 'Bengali', nativeName: 'বাংলা', flag: '🇧🇩' },
  ur: { name: 'Urdu', nativeName: 'اردو', flag: '🇵🇰' },
  fa: { name: 'Persian', nativeName: 'فارسی', flag: '🇮🇷' },
  he: { name: 'Hebrew', nativeName: 'עברית', flag: '🇮🇱' },
  
  // Amériques
  'pt-BR': { name: 'Portuguese (Brazil)', nativeName: 'Português (Brasil)', flag: '🇧🇷' },
  'es-MX': { name: 'Spanish (Mexico)', nativeName: 'Español (México)', flag: '🇲🇽' },
  'es-AR': { name: 'Spanish (Argentina)', nativeName: 'Español (Argentina)', flag: '🇦🇷' },
  'en-US': { name: 'English (US)', nativeName: 'English (US)', flag: '🇺🇸' },
  'en-CA': { name: 'English (Canada)', nativeName: 'English (Canada)', flag: '🇨🇦' },
  'fr-CA': { name: 'French (Canada)', nativeName: 'Français (Canada)', flag: '🇨🇦' },
  
  // Afrique
  sw: { name: 'Swahili', nativeName: 'Kiswahili', flag: '🇰🇪' },
  am: { name: 'Amharic', nativeName: 'አማርኛ', flag: '🇪🇹' },
  zu: { name: 'Zulu', nativeName: 'isiZulu', flag: '🇿🇦' },
  af: { name: 'Afrikaans', nativeName: 'Afrikaans', flag: '🇿🇦' },
  
  // Océanie
  'en-AU': { name: 'English (Australia)', nativeName: 'English (Australia)', flag: '🇦🇺' },
  'en-NZ': { name: 'English (New Zealand)', nativeName: 'English (New Zealand)', flag: '🇳🇿' },
};

// Default French translations to prevent undefined errors
const defaultTranslations: Translations = {
  nav: {
    home: 'Accueil',
    login: 'Connexion',
    register: 'Inscription',
    dashboard: 'Tableau de bord',
    logout: 'Déconnexion',
    back: 'Retour'
  },
  home: {
    title: 'Tovyo',
    subtitle: 'Créateur de sites web',
    newFeature: 'Nouveau',
    heroTitle: 'Créez votre site web en quelques minutes',
    heroSubtitle: 'Aucune compétence technique requise',
    discoverPlans: 'Découvrir nos plans',
    startFree: 'Commencer gratuitement',
    whyChoose: 'Pourquoi choisir Tovyo ?',
    whySubtitle: 'La solution complète pour votre présence en ligne',
    ultraFast: 'Ultra-rapide',
    ultraFastDesc: 'Sites optimisés pour la vitesse',
    noCode: 'Sans code',
    noCodeDesc: 'Création intuitive et simple',
    professional: 'Professionnel',
    professionalDesc: 'Designs modernes et élégants',
    choosePlan: 'Choisissez votre plan',
    choosePlanSubtitle: 'Des solutions adaptées à tous vos besoins',
    mostPopular: 'Le plus populaire',
    subscribeNow: "S'abonner maintenant",
    alreadySubscribed: 'Déjà abonné ?',
    accessDashboard: 'Accéder au tableau de bord',
    createSite: 'Créer un site',
    footer: 'Créé avec Tovyo'
  },
  auth: {
    welcomeBack: 'Bon retour !',
    connectAccount: 'Connectez-vous à votre compte',
    createAccount: 'Créer un compte',
    joinTovyo: 'Rejoignez Tovyo',
    email: 'Email',
    password: 'Mot de passe',
    confirmPassword: 'Confirmer le mot de passe',
    fullName: 'Nom complet',
    rememberMe: 'Se souvenir de moi',
    forgotPassword: 'Mot de passe oublié ?',
    signIn: 'Se connecter',
    signUp: "S'inscrire",
    connecting: 'Connexion...',
    creatingAccount: 'Création du compte...',
    noAccount: "Pas encore de compte ?",
    hasAccount: 'Déjà un compte ?',
    acceptTerms: "J'accepte les",
    termsOfUse: "conditions d'utilisation",
    privacyPolicy: 'politique de confidentialité',
    loginError: 'Erreur de connexion',
    registrationError: "Erreur lors de l'inscription",
    invalidCredentials: 'Identifiants invalides',
    emailNotConfirmed: 'Email non confirmé',
    tooManyRequests: 'Trop de tentatives',
    userAlreadyExists: 'Utilisateur déjà existant',
    passwordTooShort: 'Mot de passe trop court',
    invalidEmailFormat: 'Format email invalide',
    unexpectedError: 'Erreur inattendue',
    needHelp: "Besoin d'aide ?",
    helpTips: 'Conseils et astuces',
    passwordsDontMatch: 'Les mots de passe ne correspondent pas',
    passwordMinLength: 'Le mot de passe doit contenir au moins 6 caractères'
  },
  dashboard: {
    welcome: 'Bienvenue',
    manageWebsites: 'Gérez vos sites web',
    activeSites: 'Sites actifs',
    allOnline: 'Tous en ligne',
    totalVisits: 'Visites totales',
    thisMonth: 'Ce mois-ci',
    subscription: 'Abonnement',
    loading: 'Chargement...',
    mySites: 'Mes sites',
    newSite: 'Nouveau site',
    visits: 'visites',
    updatedAgo: 'Mis à jour il y a',
    viewSite: 'Voir le site',
    noSites: 'Aucun site créé',
    noSitesDesc: 'Commencez par créer votre premier site web',
    createFirstSite: 'Créer mon premier site',
    subscriptionActivated: 'Abonnement activé',
    subscriptionActivatedDesc: 'Vous pouvez maintenant créer vos sites web'
  },
  createSite: {
    title: 'Créer un nouveau site',
    subtitle: 'Quelques informations pour personnaliser votre site',
    yourName: 'Votre nom',
    yourEmail: 'Votre email',
    businessType: 'Type d\'activité',
    selectSector: 'Sélectionnez votre secteur',
    describeActivity: 'Décrivez votre activité',
    preferredStyle: 'Style préféré',
    mainColors: 'Couleurs principales',
    createNow: 'Créer maintenant',
    creating: 'Création en cours...',
    readyIn: 'Votre site sera prêt dans quelques minutes',
    businessTypes: {
      restaurant: 'Restaurant',
      ecommerce: 'E-commerce',
      services: 'Services',
      creative: 'Créatif',
      consultant: 'Consultant',
      realEstate: 'Immobilier',
      health: 'Santé',
      technology: 'Technologie',
      other: 'Autre'
    },
    styles: {
      modern: 'Moderne',
      creative: 'Créatif',
      corporate: 'Corporate',
      playful: 'Ludique'
    },
    colors: {
      blue: 'Bleu',
      green: 'Vert',
      purple: 'Violet',
      orange: 'Orange'
    }
  },
  thankYou: {
    title: 'Merci !',
    subtitle: 'Votre site est en cours de création',
    estimatedTime: 'Temps estimé : 3-5 minutes',
    notification: 'Vous recevrez une notification par email',
    maxTime: 'Maximum 10 minutes',
    secureEmail: 'Email sécurisé',
    whatsHappening: 'Que se passe-t-il maintenant ?',
    analyzingPreferences: 'Analyse de vos préférences',
    generatingDesign: 'Génération du design',
    optimizingMobile: 'Optimisation mobile',
    configuringHosting: 'Configuration de l\'hébergement',
    backHome: 'Retour à l\'accueil',
    createAnother: 'Créer un autre site',
    noEmail: 'Vous n\'avez pas reçu d\'email ?',
    contactUs: 'Contactez-nous'
  },
  plans: {
    starter: 'Starter',
    starterDesc: 'Parfait pour commencer',
    pro: 'Pro',
    proDesc: 'Pour les professionnels',
    features: {
      oneSite: '1 site web',
      secureHosting: 'Hébergement sécurisé',
      emailSupport: 'Support par email',
      freeSSL: 'SSL gratuit',
      modernTemplates: 'Templates modernes',
      threeSites: '3 sites web',
      prioritySupport: 'Support prioritaire',
      realTimeUpdates: 'Mises à jour en temps réel',
      advancedAnalytics: 'Analytics avancées',
      premiumTemplates: 'Templates premium',
      customDomain: 'Domaine personnalisé'
    }
  },
  subscriptionStatus: {
    noSubscription: 'Aucun abonnement',
    active: 'Actif',
    trialing: 'Période d\'essai',
    pastDue: 'En retard',
    canceled: 'Annulé',
    incomplete: 'Incomplet',
    notStarted: 'Non démarré'
  },
  demo: {
    restaurant: {
      name: 'Le Petit Bistrot',
      welcome: 'Bienvenue',
      subtitle: 'Cuisine française authentique',
      menu: 'Menu',
      about: 'À propos',
      contact: 'Contact',
      reserve: 'Réserver',
      menuOfDay: 'Menu du jour',
      menuSubtitle: 'Découvrez nos spécialités',
      starters: 'Entrées',
      mains: 'Plats',
      desserts: 'Desserts',
      ourStory: 'Notre histoire',
      storyText: 'Depuis 1985, nous proposons une cuisine française authentique',
      experience: 'ans d\'expérience',
      satisfiedClients: 'clients satisfaits',
      phone: 'Téléphone',
      address: 'Adresse',
      hours: 'Horaires',
      reserveNow: 'Réserver maintenant',
      footer: 'Le Petit Bistrot - Tous droits réservés'
    },
    portfolio: {
      name: 'Marie Dubois',
      photographer: 'Photographe',
      subtitle: 'Capturer vos moments précieux',
      portfolio: 'Portfolio',
      about: 'À propos',
      services: 'Services',
      contact: 'Contact',
      reserve: 'Réserver',
      viewPortfolio: 'Voir le portfolio',
      contactMe: 'Me contacter',
      weddings: 'Mariages',
      experience: 'ans d\'expérience',
      satisfied: 'clients satisfaits',
      myWork: 'Mon travail',
      portfolioSubtitle: 'Une sélection de mes meilleures photos',
      all: 'Tout',
      portraits: 'Portraits',
      nature: 'Nature',
      events: 'Événements',
      aboutMe: 'À propos de moi',
      aboutText: 'Passionnée de photographie depuis plus de 10 ans',
      passion: 'Passion',
      since: 'Depuis',
      myServices: 'Mes services',
      servicesSubtitle: 'Des prestations adaptées à vos besoins',
      weddingsService: 'Mariages',
      weddingsDesc: 'Immortalisez votre jour J',
      portraitsService: 'Portraits',
      portraitsDesc: 'Révélez votre personnalité',
      eventsService: 'Événements',
      eventsDesc: 'Capturez vos moments spéciaux',
      talkProject: 'Parlons de votre projet',
      projectDesc: 'Contactez-moi pour discuter de vos besoins',
      sendMessage: 'Envoyer un message',
      footer: 'Marie Dubois Photography - Tous droits réservés'
    }
  },
  common: {
    loading: 'Chargement...',
    error: 'Erreur',
    success: 'Succès',
    cancel: 'Annuler',
    confirm: 'Confirmer',
    save: 'Sauvegarder',
    delete: 'Supprimer',
    edit: 'Modifier',
    close: 'Fermer',
    next: 'Suivant',
    previous: 'Précédent',
    search: 'Rechercher',
    filter: 'Filtrer',
    sort: 'Trier',
    createdWith: 'Créé avec'
  }
};

interface LanguageContextType {
  currentLanguage: string;
  setLanguage: (language: string) => void;
  t: Translations;
  availableLanguages: typeof supportedLanguages;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('fr');
  const [translations, setTranslations] = useState<Translations>(defaultTranslations);

  useEffect(() => {
    // Charger la langue sauvegardée ou détecter la langue du navigateur
    const savedLanguage = localStorage.getItem('tovyoapp-language');
    if (savedLanguage && supportedLanguages[savedLanguage as keyof typeof supportedLanguages]) {
      setCurrentLanguage(savedLanguage);
    } else {
      // Détecter la langue du navigateur
      const browserLanguage = navigator.language.toLowerCase();
      const languageCode = browserLanguage.split('-')[0];
      
      if (supportedLanguages[browserLanguage as keyof typeof supportedLanguages]) {
        setCurrentLanguage(browserLanguage);
      } else if (supportedLanguages[languageCode as keyof typeof supportedLanguages]) {
        setCurrentLanguage(languageCode);
      } else {
        setCurrentLanguage('fr'); // Français par défaut
      }
    }
  }, []);

  useEffect(() => {
    // Charger les traductions pour la langue actuelle
    loadTranslations(currentLanguage);
  }, [currentLanguage]);

  const loadTranslations = async (language: string) => {
    try {
      const translationModule = await import(`../translations/${language}.ts`);
      setTranslations(translationModule.default);
    } catch (error) {
      console.warn(`Translations not found for ${language}, falling back to French`);
      try {
        const fallbackModule = await import('../translations/fr.ts');
        setTranslations(fallbackModule.default);
      } catch (fallbackError) {
        console.error('Failed to load fallback translations:', fallbackError);
        // Keep default translations if all else fails
        setTranslations(defaultTranslations);
      }
    }
  };

  const setLanguage = (language: string) => {
    setCurrentLanguage(language);
    localStorage.setItem('tovyoapp-language', language);
  };

  const value = {
    currentLanguage,
    setLanguage,
    t: translations,
    availableLanguages: supportedLanguages
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};