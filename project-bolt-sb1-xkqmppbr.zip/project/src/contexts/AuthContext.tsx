import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import type { User as SupabaseUser } from '@supabase/supabase-js';

interface User {
  id: string;
  email: string;
  name: string;
  hasActiveSubscription: boolean;
  subscriptionPlan?: string;
  subscriptionStatus?: string;
  customerId?: string;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    const initializeAuth = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          setIsLoading(false);
          return;
        }

        if (session?.user) {
          console.log('Initial session found for:', session.user.email);
          await loadUserData(session.user);
        } else {
          console.log('No initial session found');
          setIsLoading(false);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        setIsLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event, session?.user?.email);
      
      if (event === 'SIGNED_IN' && session?.user) {
        console.log('User signed in:', session.user.email);
        await loadUserData(session.user);
      } else if (event === 'SIGNED_OUT') {
        console.log('User signed out');
        setUser(null);
        setIsLoading(false);
      } else if (event === 'TOKEN_REFRESHED' && session?.user) {
        console.log('Token refreshed for:', session.user.email);
        await loadUserData(session.user);
      } else {
        setIsLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadUserData = async (supabaseUser: SupabaseUser) => {
    try {
      console.log('Loading user data for:', supabaseUser.email);
      
      // Vérifier si c'est un admin
      const isAdmin = supabaseUser.email === 'admin@tovyoapp.com';

      // Get user profile
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', supabaseUser.id)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Error loading profile:', profileError);
        // Continue without profile data
      }

      // Pour les admins, on ne charge pas les données d'abonnement
      let subscription = null;
      let customer = null;

      if (!isAdmin) {
        try {
          // Get subscription data
          const { data: subscriptionData, error: subscriptionError } = await supabase
            .from('stripe_user_subscriptions')
            .select('*')
            .single();

          if (subscriptionError && subscriptionError.code !== 'PGRST116') {
            console.error('Error loading subscription:', subscriptionError);
          } else {
            subscription = subscriptionData;
          }

          // Get customer data
          const { data: customerData, error: customerError } = await supabase
            .from('stripe_customers')
            .select('customer_id')
            .eq('user_id', supabaseUser.id)
            .eq('deleted_at', null)
            .single();

          if (customerError && customerError.code !== 'PGRST116') {
            console.error('Error loading customer:', customerError);
          } else {
            customer = customerData;
          }
        } catch (error) {
          console.error('Error loading subscription/customer data:', error);
          // Continue without subscription data
        }
      }

      const hasActiveSubscription = subscription?.subscription_status === 'active' || 
                                   subscription?.subscription_status === 'trialing';

      const userData: User = {
        id: supabaseUser.id,
        email: supabaseUser.email || '',
        name: profile?.full_name || 
              supabaseUser.user_metadata?.full_name || 
              supabaseUser.email?.split('@')[0] || 
              'User',
        hasActiveSubscription: isAdmin ? true : hasActiveSubscription,
        subscriptionPlan: subscription?.price_id ? getPlanNameFromPriceId(subscription.price_id) : undefined,
        subscriptionStatus: subscription?.subscription_status || undefined,
        customerId: customer?.customer_id || undefined,
        isAdmin: isAdmin,
      };

      console.log('User data loaded successfully:', userData);
      setUser(userData);
    } catch (error) {
      console.error('Error loading user data:', error);
      // Set basic user data even if profile loading fails
      const userData: User = {
        id: supabaseUser.id,
        email: supabaseUser.email || '',
        name: supabaseUser.user_metadata?.full_name || 
              supabaseUser.email?.split('@')[0] || 
              'User',
        hasActiveSubscription: supabaseUser.email === 'admin@tovyoapp.com',
        isAdmin: supabaseUser.email === 'admin@tovyoapp.com',
      };
      setUser(userData);
    } finally {
      setIsLoading(false);
    }
  };

  const getPlanNameFromPriceId = (priceId: string): string => {
    const priceMap: Record<string, string> = {
      'price_1RXTq4DcUBznaKKpaYSyGQG3': 'Starter',
      'price_1RXTohDcUBznaKKpLkvOQyYB': 'Pro',
    };
    return priceMap[priceId] || 'Unknown Plan';
  };

  const refreshUser = async () => {
    try {
      const { data: { user: supabaseUser }, error } = await supabase.auth.getUser();
      if (error) {
        console.error('Error refreshing user:', error);
        return;
      }
      if (supabaseUser) {
        await loadUserData(supabaseUser);
      }
    } catch (error) {
      console.error('Error in refreshUser:', error);
    }
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    console.log('Starting login process for:', email);
    
    try {
      setIsLoading(true);
      
      // Clear any existing session first
      await supabase.auth.signOut();
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (error) {
        console.error('Login error:', error);
        
        // Messages d'erreur plus clairs en français
        if (error.message.includes('Invalid login credentials') || 
            error.message.includes('invalid_credentials') ||
            error.message.includes('Invalid email or password')) {
          return { success: false, error: 'Email ou mot de passe incorrect. Vérifiez vos informations.' };
        } else if (error.message.includes('Email not confirmed')) {
          return { success: false, error: 'Veuillez confirmer votre email avant de vous connecter.' };
        } else if (error.message.includes('Too many requests')) {
          return { success: false, error: 'Trop de tentatives. Veuillez patienter quelques minutes.' };
        } else if (error.message.includes('signup_disabled')) {
          return { success: false, error: 'Les inscriptions sont temporairement désactivées.' };
        } else if (error.message.includes('Network request failed') || 
                   error.message.includes('fetch') ||
                   error.message.includes('Failed to fetch')) {
          return { success: false, error: 'Problème de connexion. Vérifiez votre connexion internet.' };
        }
        
        return { success: false, error: `Erreur de connexion: ${error.message}` };
      }

      if (data.user && data.session) {
        console.log('Login successful for:', data.user.email);
        // loadUserData sera appelé automatiquement par onAuthStateChange
        return { success: true };
      }

      return { success: false, error: 'Aucun utilisateur retourné après la connexion' };
    } catch (error: any) {
      console.error('Login error:', error);
      
      // Gestion des erreurs réseau
      if (error.name === 'TypeError' || error.message.includes('fetch')) {
        return { success: false, error: 'Problème de connexion. Vérifiez votre connexion internet.' };
      }
      
      return { success: false, error: 'Une erreur inattendue est survenue lors de la connexion.' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    console.log('Starting registration process for:', email);
    
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            full_name: name.trim(),
          },
        },
      });

      if (error) {
        console.error('Registration error:', error);
        
        // Messages d'erreur plus clairs en français
        if (error.message.includes('User already registered') || 
            error.message.includes('already_registered')) {
          return { success: false, error: 'Un compte existe déjà avec cette adresse email.' };
        } else if (error.message.includes('Password should be at least')) {
          return { success: false, error: 'Le mot de passe doit contenir au moins 6 caractères.' };
        } else if (error.message.includes('Unable to validate email address') || 
                   error.message.includes('invalid_email')) {
          return { success: false, error: 'Format d\'email invalide.' };
        } else if (error.message.includes('signup_disabled')) {
          return { success: false, error: 'Les inscriptions sont temporairement désactivées.' };
        } else if (error.message.includes('Network request failed') || 
                   error.message.includes('fetch') ||
                   error.message.includes('Failed to fetch')) {
          return { success: false, error: 'Problème de connexion. Vérifiez votre connexion internet.' };
        }
        
        return { success: false, error: `Erreur d'inscription: ${error.message}` };
      }

      if (data.user) {
        console.log('Registration successful for:', data.user.email);
        
        // Si l'utilisateur est confirmé automatiquement, charger ses données
        if (data.session) {
          // loadUserData sera appelé automatiquement par onAuthStateChange
          return { success: true };
        } else {
          // Si confirmation email requise
          return { success: true };
        }
      }

      return { success: false, error: 'Erreur lors de la création du compte.' };
    } catch (error: any) {
      console.error('Registration error:', error);
      
      // Gestion des erreurs réseau
      if (error.name === 'TypeError' || error.message.includes('fetch')) {
        return { success: false, error: 'Problème de connexion. Vérifiez votre connexion internet.' };
      }
      
      return { success: false, error: 'Une erreur inattendue est survenue lors de l\'inscription.' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    console.log('Logging out user');
    try {
      setIsLoading(true);
      await supabase.auth.signOut();
      setUser(null);
    } catch (error) {
      console.error('Error during logout:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    user,
    login,
    register,
    logout,
    refreshUser,
    isLoading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};