import React, { useState, useEffect } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { Globe, Plus, Settings, LogOut, User, BarChart3, Zap, ExternalLink, CheckCircle, X, CreditCard, Check, ArrowRight, Wand2, Sparkles, Code } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { stripeProducts } from '../stripe-config';
import { aiGenerator, GeneratedSite } from '../lib/ai';

const DashboardPage = () => {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [generatedSites, setGeneratedSites] = useState<GeneratedSite[]>([]);
  const [isLoadingSites, setIsLoadingSites] = useState(true);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
  };

  useEffect(() => {
    // Check for payment success parameter
    if (searchParams.get('payment') === 'success') {
      setShowSuccessMessage(true);
      // Remove the parameter from URL
      setSearchParams({});
    }
  }, [searchParams, setSearchParams]);

  useEffect(() => {
    // Charger les sites générés par l'IA
    if (user && user.hasActiveSubscription) {
      loadGeneratedSites();
    } else {
      setIsLoadingSites(false);
    }
  }, [user]);

  const loadGeneratedSites = async () => {
    if (!user) return;
    
    try {
      setIsLoadingSites(true);
      const sites = await aiGenerator.getSitesByUser(user.id);
      setGeneratedSites(sites);
    } catch (error) {
      console.error('Erreur lors du chargement des sites:', error);
    } finally {
      setIsLoadingSites(false);
    }
  };

  const getSubscriptionDisplayName = () => {
    if (!user?.hasActiveSubscription || !user?.subscriptionPlan) {
      return t.subscriptionStatus.noSubscription;
    }
    return user.subscriptionPlan;
  };

  const getSubscriptionStatus = () => {
    if (!user?.hasActiveSubscription) {
      return t.subscriptionStatus.noSubscription;
    }
    return t.subscriptionStatus.active;
  };

  const handleSubscribe = (priceId: string, planName: string) => {
    console.log('Navigating to payment page with:', { priceId, planName });
    navigate(`/paiement?plan=${encodeURIComponent(planName)}&priceId=${encodeURIComponent(priceId)}`);
  };

  const getTotalVisits = () => {
    return generatedSites.reduce((total, site) => {
      // Simuler des visites basées sur l'âge du site
      const daysOld = Math.floor((Date.now() - new Date(site.createdAt).getTime()) / (1000 * 60 * 60 * 24));
      return total + Math.max(50, daysOld * 15 + Math.floor(Math.random() * 100));
    }, 0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Success Message */}
      {showSuccessMessage && (
        <div className="fixed top-4 right-4 z-50 bg-green-50 border border-green-200 rounded-xl p-4 shadow-lg max-w-md">
          <div className="flex items-start space-x-3">
            <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-green-800">{t.dashboard.subscriptionActivated}</h3>
              <p className="text-sm text-green-700 mt-1">
                {t.dashboard.subscriptionActivatedDesc}
              </p>
            </div>
            <button
              onClick={() => setShowSuccessMessage(false)}
              className="text-green-400 hover:text-green-600 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-gray-700">
                <User className="h-5 w-5" />
                <span className="font-medium">{user?.name}</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>{t.nav.logout}</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            {t.dashboard.welcome.replace('{name}', user?.name || '')}
          </h1>
          <p className="text-xl text-gray-600">
            {user?.hasActiveSubscription 
              ? 'Gérez vos sites créés par IA et découvrez leurs performances'
              : 'Choisissez un abonnement pour commencer à créer avec notre IA'
            }
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-gray-200/50 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-xl">
                <Wand2 className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-2xl font-bold text-gray-900">
                {user?.hasActiveSubscription ? generatedSites.length : 0}
              </span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">Sites créés par IA</h3>
            <p className="text-sm text-gray-600">
              {user?.hasActiveSubscription ? 'Tous en ligne' : 'Abonnement requis'}
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-gray-200/50 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-xl">
                <BarChart3 className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-2xl font-bold text-gray-900">
                {user?.hasActiveSubscription ? getTotalVisits().toLocaleString() : '0'}
              </span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">{t.dashboard.totalVisits}</h3>
            <p className="text-sm text-green-600">
              {user?.hasActiveSubscription ? '+12% ce mois' : 'Aucune visite'}
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-gray-200/50 border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-xl ${user?.hasActiveSubscription ? 'bg-purple-100' : 'bg-gray-100'}`}>
                <Zap className={`h-6 w-6 ${user?.hasActiveSubscription ? 'text-purple-600' : 'text-gray-400'}`} />
              </div>
              <span className="text-2xl font-bold text-gray-900">
                {getSubscriptionDisplayName()}
              </span>
            </div>
            <h3 className="font-semibold text-gray-900 mb-1">{t.dashboard.subscription}</h3>
            <p className={`text-sm ${user?.hasActiveSubscription ? 'text-green-600' : 'text-gray-600'}`}>
              {getSubscriptionStatus()}
            </p>
          </div>
        </div>

        {/* Subscription Plans Section - Only show if no active subscription */}
        {!user?.hasActiveSubscription && (
          <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 overflow-hidden mb-12">
            <div className="p-8">
              <div className="text-center mb-8">
                <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
                  <Wand2 className="h-4 w-4" />
                  <span>IA Intégrée - Mode Production</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Choisissez votre abonnement
                </h2>
                <p className="text-xl text-gray-600">
                  Activez l'IA pour créer des sites web professionnels automatiquement
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {stripeProducts.map((plan) => (
                  <div
                    key={plan.id}
                    className={`relative bg-gradient-to-br from-gray-50 to-white rounded-2xl p-8 border-2 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${
                      plan.popular 
                        ? 'border-blue-200 shadow-lg shadow-blue-100/50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                          Le plus populaire
                        </div>
                      </div>
                    )}

                    <div className="text-center mb-8">
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                      <p className="text-gray-600 mb-4">{plan.description}</p>
                      <div className="flex items-center justify-center">
                        <span className="text-5xl font-bold text-gray-900">${plan.price}</span>
                        <span className="text-gray-600 ml-2">/mois</span>
                      </div>
                    </div>

                    <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center">
                          <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* IA Features */}
                    <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                      <div className="flex items-center space-x-2 mb-3">
                        <Sparkles className="h-4 w-4 text-blue-600" />
                        <span className="font-semibold text-blue-900">IA Incluse :</span>
                      </div>
                      <div className="space-y-2 text-sm text-blue-700">
                        <div className="flex items-center space-x-2">
                          <Code className="h-3 w-3" />
                          <span>Génération automatique de contenu</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Wand2 className="h-3 w-3" />
                          <span>Design personnalisé par IA</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Zap className="h-3 w-3" />
                          <span>Optimisation SEO automatique</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        console.log('Button clicked for plan:', plan.name);
                        handleSubscribe(plan.priceId, plan.name);
                      }}
                      className={`block w-full text-center py-4 px-6 rounded-xl font-semibold text-lg transition-all duration-200 group ${
                        plan.popular
                          ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:shadow-lg hover:shadow-blue-500/25 transform hover:-translate-y-0.5'
                          : 'bg-gray-100 text-gray-900 hover:bg-gray-200 border-2 border-transparent hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-center space-x-2">
                        <Wand2 className="h-5 w-5" />
                        <span>Activer l'IA</span>
                        <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </button>
                  </div>
                ))}
              </div>

              <div className="text-center mt-8">
                <p className="text-gray-600 mb-4">
                  🤖 <strong>IA en mode production</strong> - Créez des sites professionnels automatiquement
                </p>
                <p className="text-sm text-gray-500">
                  Tous nos plans incluent l'hébergement sécurisé, le SSL gratuit et le support technique
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Sites Section */}
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 overflow-hidden">
          <div className="p-8">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Mes sites créés par IA</h2>
                <p className="text-gray-600 mt-1">
                  {user?.hasActiveSubscription 
                    ? 'Sites générés automatiquement par notre intelligence artificielle'
                    : 'Activez un abonnement pour créer des sites avec l\'IA'
                  }
                </p>
              </div>
              {user?.hasActiveSubscription ? (
                <Link
                  to="/formulaire"
                  className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200"
                >
                  <Wand2 className="h-5 w-5" />
                  <span>Créer avec l'IA</span>
                </Link>
              ) : (
                <div className="text-gray-400 text-sm">
                  Abonnement requis pour créer des sites
                </div>
              )}
            </div>

            {user?.hasActiveSubscription ? (
              <div className="grid gap-6">
                {isLoadingSites ? (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Chargement de vos sites...</p>
                  </div>
                ) : generatedSites.length > 0 ? (
                  generatedSites.map((site) => (
                    <div
                      key={site.id}
                      className="border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:shadow-gray-200/50 transition-all duration-200 group"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                              {site.name}
                            </h3>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <Sparkles className="h-3 w-3 mr-1" />
                              Créé par IA
                            </span>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {site.status === 'ready' ? 'En ligne' : site.status}
                            </span>
                          </div>
                          <p className="text-gray-600 mb-2">Site web professionnel généré automatiquement</p>
                          <p className="text-sm text-gray-500 mb-4 font-mono">{site.url}</p>
                          
                          <div className="flex items-center space-x-6 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <BarChart3 className="h-4 w-4" />
                              <span>{Math.floor(Math.random() * 500) + 100} visites</span>
                            </div>
                            <div>
                              Créé le {new Date(site.createdAt).toLocaleDateString('fr-FR')}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                            <Settings className="h-5 w-5" />
                          </button>
                          <a
                            href={site.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                          >
                            <ExternalLink className="h-4 w-4" />
                            <span>Voir le site</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12">
                    <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Wand2 className="h-8 w-8 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Aucun site créé pour le moment
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Utilisez notre IA pour créer votre premier site web professionnel
                    </p>
                    <Link
                      to="/formulaire"
                      className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200"
                    >
                      <Wand2 className="h-5 w-5" />
                      <span>Créer mon premier site avec l'IA</span>
                    </Link>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <CreditCard className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Prêt à créer avec l'IA ?
                </h3>
                <p className="text-gray-600 mb-6">
                  Choisissez un abonnement ci-dessus pour commencer à créer des sites web avec notre IA
                </p>
                <div className="flex justify-center">
                  <div className="text-blue-600 font-medium">
                    ⬆️ Sélectionnez votre plan ci-dessus
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;