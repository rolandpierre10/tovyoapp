import React from 'react';
import { RefreshCw, Download } from 'lucide-react';
import { usePWA } from '../hooks/usePWA';

const PWAUpdatePrompt: React.FC = () => {
  const { hasUpdate, reloadApp } = usePWA();

  if (!hasUpdate) {
    return null;
  }

  return (
    <div className="fixed top-4 left-4 right-4 md:left-auto md:right-4 md:max-w-sm z-50 animate-slideDown">
      <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 p-6 relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-blue-50 opacity-50"></div>
        
        {/* Content */}
        <div className="relative z-10">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-gradient-to-r from-green-600 to-blue-600 p-2 rounded-lg">
              <Download className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Mise à jour disponible</h3>
              <p className="text-sm text-gray-600">Une nouvelle version de TovyoApp est prête</p>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4">
            <p className="text-blue-800 text-sm">
              ✨ Nouvelles fonctionnalités et améliorations disponibles
            </p>
          </div>

          <button
            onClick={reloadApp}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white py-3 px-4 rounded-xl font-semibold text-sm hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Mettre à jour maintenant</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PWAUpdatePrompt;