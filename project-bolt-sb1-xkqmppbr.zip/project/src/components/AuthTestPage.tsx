import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Globe, ArrowLeft, Database, CheckCircle, XCircle, AlertTriangle, Settings } from 'lucide-react';
import { supabase } from '../lib/supabase';

const AuthTestPage = () => {
  const [testResults, setTestResults] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const runTests = async () => {
    setIsLoading(true);
    const results = {
      supabaseConnection: false,
      authService: false,
      database: false,
      error: null
    };

    try {
      // Test 1: Connexion Supabase
      const { data, error } = await supabase.from('profiles').select('count').limit(1);
      if (!error) {
        results.supabaseConnection = true;
        results.database = true;
      }

      // Test 2: Service d'authentification
      const { data: authData } = await supabase.auth.getSession();
      results.authService = true;

    } catch (error: any) {
      results.error = error.message;
    }

    setTestResults(results);
    setIsLoading(false);
  };

  const testSignUp = async () => {
    try {
      const testEmail = `test-${Date.now()}@example.com`;
      const { data, error } = await supabase.auth.signUp({
        email: testEmail,
        password: 'test123456',
        options: {
          data: {
            full_name: 'Test User'
          }
        }
      });

      if (error) {
        alert(`Erreur d'inscription: ${error.message}`);
      } else {
        alert('Test d\'inscription réussi ! (Compte de test créé)');
      }
    } catch (error: any) {
      alert(`Erreur: ${error.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp - Test
              </span>
            </Link>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Database className="h-8 w-8 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Test de l'authentification
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Diagnostiquer les problèmes de connexion et d'inscription
          </p>
        </div>

        {/* Configuration Status */}
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Configuration actuelle</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <span className="font-medium text-gray-700">Supabase URL</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_URL !== 'your-project.supabase.co'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_URL !== 'your-project.supabase.co' ? 'Configuré' : 'Non configuré'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <span className="font-medium text-gray-700">Supabase Key</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  import.meta.env.VITE_SUPABASE_ANON_KEY && import.meta.env.VITE_SUPABASE_ANON_KEY !== 'your-anon-key'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {import.meta.env.VITE_SUPABASE_ANON_KEY && import.meta.env.VITE_SUPABASE_ANON_KEY !== 'your-anon-key' ? 'Configuré' : 'Non configuré'}
                </span>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-yellow-900 mb-2">Configuration requise</h3>
                  <p className="text-yellow-800 text-sm">
                    Pour que l'authentification fonctionne, vous devez configurer Supabase. 
                    Cliquez sur "Connect to Supabase" en haut à droite de l'écran.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Test Section */}
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Tests de connexion</h2>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <button
              onClick={runTests}
              disabled={isLoading}
              className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Test en cours...</span>
                </>
              ) : (
                <>
                  <Database className="h-5 w-5" />
                  <span>Tester la connexion</span>
                </>
              )}
            </button>
            
            <button
              onClick={testSignUp}
              className="flex-1 bg-green-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Settings className="h-5 w-5" />
              <span>Tester l'inscription</span>
            </button>
          </div>

          {testResults && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">Résultats des tests :</h3>
              
              <div className="grid gap-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <span className="font-medium text-gray-700">Connexion Supabase</span>
                  <div className="flex items-center space-x-2">
                    {testResults.supabaseConnection ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      testResults.supabaseConnection
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {testResults.supabaseConnection ? 'Succès' : 'Échec'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <span className="font-medium text-gray-700">Service d'authentification</span>
                  <div className="flex items-center space-x-2">
                    {testResults.authService ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      testResults.authService
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {testResults.authService ? 'Disponible' : 'Indisponible'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <span className="font-medium text-gray-700">Base de données</span>
                  <div className="flex items-center space-x-2">
                    {testResults.database ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      testResults.database
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {testResults.database ? 'Accessible' : 'Inaccessible'}
                    </span>
                  </div>
                </div>
              </div>

              {testResults.error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                  <h4 className="font-semibold text-red-900 mb-2">Erreur détectée :</h4>
                  <p className="text-red-800 text-sm font-mono">{testResults.error}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Comment résoudre les problèmes</h2>
          
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <h3 className="font-semibold text-blue-900 mb-3">1. Configurer Supabase</h3>
              <p className="text-blue-800 mb-4">
                Pour que l'authentification fonctionne, vous devez connecter votre projet à Supabase :
              </p>
              <ol className="text-blue-700 text-sm space-y-2">
                <li>1. Cliquez sur le bouton "Connect to Supabase" en haut à droite</li>
                <li>2. Suivez les instructions pour créer un projet Supabase</li>
                <li>3. Les variables d'environnement seront configurées automatiquement</li>
                <li>4. Revenez sur cette page pour tester la connexion</li>
              </ol>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-xl p-6">
              <h3 className="font-semibold text-green-900 mb-3">2. Tester l'authentification</h3>
              <p className="text-green-800 mb-4">
                Une fois Supabase configuré, vous pourrez :
              </p>
              <ul className="text-green-700 text-sm space-y-2">
                <li>• Créer des comptes utilisateur</li>
                <li>• Se connecter et se déconnecter</li>
                <li>• Accéder au dashboard</li>
                <li>• Gérer les abonnements</li>
              </ul>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
              <h3 className="font-semibold text-yellow-900 mb-3">3. Mode démo</h3>
              <p className="text-yellow-800 text-sm">
                En attendant la configuration de Supabase, vous pouvez explorer les pages de démonstration 
                qui ne nécessitent pas d'authentification.
              </p>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="mt-8 grid md:grid-cols-3 gap-4">
          <Link
            to="/demo/restaurant-demo"
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200 text-center"
          >
            <h3 className="font-semibold text-gray-900 mb-2">Démo Restaurant</h3>
            <p className="text-gray-600 text-sm">Voir un exemple de site restaurant</p>
          </Link>
          
          <Link
            to="/demo/portfolio-demo"
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200 text-center"
          >
            <h3 className="font-semibold text-gray-900 mb-2">Démo Portfolio</h3>
            <p className="text-gray-600 text-sm">Voir un exemple de portfolio</p>
          </Link>
          
          <Link
            to="/contact"
            className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200 text-center"
          >
            <h3 className="font-semibold text-gray-900 mb-2">Support</h3>
            <p className="text-gray-600 text-sm">Contacter l'équipe technique</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AuthTestPage;