import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Code, Globe, Zap, Check, ArrowRight, Sparkles, LogIn, UserPlus, Menu, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { stripeProducts } from '../stripe-config';
import LanguageSelector from './LanguageSelector';

const LandingPage = () => {
  const [hoveredPlan, setHoveredPlan] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleSubscribe = (priceId: string, planName: string) => {
    if (!user) {
      // Redirect to signup if not authenticated
      navigate('/inscription');
      return;
    }

    // Navigate to payment page with plan information
    navigate(`/paiement?plan=${encodeURIComponent(planName)}&priceId=${encodeURIComponent(priceId)}`);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 overflow-x-hidden">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-4">
              <LanguageSelector />
              {user ? (
                <Link
                  to="/dashboard"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all duration-200 font-medium"
                >
                  {t.nav.dashboard}
                </Link>
              ) : (
                <>
                  <Link
                    to="/connexion"
                    className="flex items-center space-x-2 text-gray-700 hover:text-gray-900 transition-colors font-medium"
                  >
                    <LogIn className="h-4 w-4" />
                    <span>{t.nav.login}</span>
                  </Link>
                  <Link
                    to="/inscription"
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all duration-200 font-medium"
                  >
                    <UserPlus className="h-4 w-4" />
                    <span>{t.nav.register}</span>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center space-x-2">
              <LanguageSelector />
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-lg text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors"
              >
                {isMobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4 animate-slideDown">
              <div className="flex flex-col space-y-4">
                <a 
                  href="#plans" 
                  onClick={closeMobileMenu}
                  className="text-gray-700 hover:text-gray-900 font-medium px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Nos plans
                </a>
                <Link 
                  to="/demo/restaurant-demo" 
                  onClick={closeMobileMenu}
                  className="text-gray-700 hover:text-gray-900 font-medium px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Démo Restaurant
                </Link>
                <Link 
                  to="/demo/portfolio-demo" 
                  onClick={closeMobileMenu}
                  className="text-gray-700 hover:text-gray-900 font-medium px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Démo Portfolio
                </Link>
                <Link 
                  to="/contact" 
                  onClick={closeMobileMenu}
                  className="text-gray-700 hover:text-gray-900 font-medium px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Contact
                </Link>
                
                <div className="border-t border-gray-200 pt-4">
                  {user ? (
                    <Link
                      to="/dashboard"
                      onClick={closeMobileMenu}
                      className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-all duration-200 font-medium"
                    >
                      <span>{t.nav.dashboard}</span>
                    </Link>
                  ) : (
                    <div className="space-y-3">
                      <Link
                        to="/connexion"
                        onClick={closeMobileMenu}
                        className="flex items-center justify-center space-x-2 text-gray-700 px-4 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition-all duration-200 font-medium"
                      >
                        <LogIn className="h-4 w-4" />
                        <span>{t.nav.login}</span>
                      </Link>
                      <Link
                        to="/inscription"
                        onClick={closeMobileMenu}
                        className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-all duration-200 font-medium"
                      >
                        <UserPlus className="h-4 w-4" />
                        <span>{t.nav.register}</span>
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-12 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-indigo-600/5"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="animate-fadeIn">
            <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-6 lg:mb-8">
              <Sparkles className="h-4 w-4" />
              <span>{t.home.newFeature}</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl lg:text-7xl font-bold text-gray-900 mb-4 lg:mb-6 leading-tight px-2">
              {t.home.heroTitle.split('professionnel')[0]}
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                professionnel
              </span>
              <br />
              {t.home.heroTitle.split('en 2 minutes')[1]}
            </h1>
            
            <p className="text-lg sm:text-xl lg:text-2xl text-gray-600 mb-8 lg:mb-12 max-w-3xl mx-auto leading-relaxed px-4">
              {t.home.heroSubtitle}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center px-4">
              <a
                href="#plans"
                className="group bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 lg:px-8 py-3 lg:py-4 rounded-xl font-semibold text-base lg:text-lg hover:shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:-translate-y-1 flex items-center space-x-2 w-full sm:w-auto justify-center"
              >
                <span>{t.home.discoverPlans}</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <Link
                to={user ? "/dashboard" : "/inscription"}
                className="text-gray-700 px-6 lg:px-8 py-3 lg:py-4 rounded-xl font-semibold text-base lg:text-lg border-2 border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all duration-200 w-full sm:w-auto text-center"
              >
                {user ? t.home.accessDashboard : t.home.startFree}
              </Link>
            </div>
          </div>
        </div>

        {/* Floating elements - Hidden on mobile */}
        <div className="hidden lg:block absolute top-20 left-10 animate-float">
          <div className="bg-white rounded-2xl p-4 shadow-xl border border-gray-100">
            <Code className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        <div className="hidden lg:block absolute top-40 right-10 animate-float" style={{ animationDelay: '2s' }}>
          <div className="bg-white rounded-2xl p-4 shadow-xl border border-gray-100">
            <Zap className="h-8 w-8 text-indigo-600" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 lg:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {t.home.whyChoose}
            </h2>
            <p className="text-lg lg:text-xl text-gray-600 max-w-2xl mx-auto px-4">
              {t.home.whySubtitle}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {[
              {
                icon: Zap,
                title: t.home.ultraFast,
                description: t.home.ultraFastDesc
              },
              {
                icon: Code,
                title: t.home.noCode,
                description: t.home.noCodeDesc
              },
              {
                icon: Globe,
                title: t.home.professional,
                description: t.home.professionalDesc
              }
            ].map((feature, index) => (
              <div
                key={index}
                className="text-center group hover:transform hover:-translate-y-2 transition-all duration-300 px-4"
              >
                <div className="bg-gradient-to-r from-blue-100 to-indigo-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:shadow-lg transition-shadow">
                  <feature.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="plans" className="py-12 lg:py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {t.home.choosePlan}
            </h2>
            <p className="text-lg lg:text-xl text-gray-600 max-w-2xl mx-auto px-4">
              {t.home.choosePlanSubtitle}
            </p>
            {!user && (
              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl max-w-md mx-auto">
                <p className="text-blue-800 text-sm">
                  💡 <strong>Créez d'abord votre compte</strong> pour vous abonner et commencer à créer vos sites
                </p>
              </div>
            )}
          </div>

          <div className="grid lg:grid-cols-2 gap-6 lg:gap-8 max-w-4xl mx-auto">
            {stripeProducts.map((plan) => (
              <div
                key={plan.id}
                className={`relative bg-white rounded-3xl p-6 lg:p-8 border-2 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 ${
                  plan.popular 
                    ? 'border-blue-200 shadow-xl shadow-blue-100/50' 
                    : 'border-gray-200 hover:border-gray-300'
                } ${hoveredPlan === plan.id ? 'scale-105' : ''}`}
                onMouseEnter={() => setHoveredPlan(plan.id)}
                onMouseLeave={() => setHoveredPlan(null)}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 lg:px-6 py-2 rounded-full text-sm font-semibold">
                      {t.home.mostPopular}
                    </div>
                  </div>
                )}

                <div className="text-center mb-6 lg:mb-8">
                  <h3 className="text-xl lg:text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4 text-sm lg:text-base">{plan.description}</p>
                  <div className="flex items-center justify-center">
                    <span className="text-4xl lg:text-5xl font-bold text-gray-900">${plan.price}</span>
                    <span className="text-gray-600 ml-2">/mois</span>
                  </div>
                </div>

                <ul className="space-y-3 lg:space-y-4 mb-6 lg:mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm lg:text-base">
                      <Check className="h-4 w-4 lg:h-5 lg:w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleSubscribe(plan.priceId, plan.name)}
                  className={`block w-full text-center py-3 lg:py-4 px-6 rounded-xl font-semibold text-base lg:text-lg transition-all duration-200 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:shadow-lg hover:shadow-blue-500/25 transform hover:-translate-y-0.5'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200 border-2 border-transparent hover:border-gray-300'
                  }`}
                >
                  {t.home.subscribeNow}
                </button>
              </div>
            ))}
          </div>

          <div className="text-center mt-8 lg:mt-12 px-4">
            <p className="text-gray-600 mb-4">{t.home.alreadySubscribed}</p>
            <button
              onClick={() => {
                if (user) {
                  // If user is logged in, redirect to payment page with first plan
                  navigate(`/paiement?plan=${encodeURIComponent(stripeProducts[0].name)}&priceId=${encodeURIComponent(stripeProducts[0].priceId)}`);
                } else {
                  // If not logged in, redirect to signup
                  navigate('/inscription');
                }
              }}
              className="inline-flex items-center text-blue-600 hover:text-blue-700 font-semibold text-base lg:text-lg group"
            >
              {user ? t.home.createSite : t.home.createSite}
              <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 lg:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 lg:gap-8 mb-6 lg:mb-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                  <Globe className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold">TovyoApp</span>
              </div>
              <p className="text-gray-400 mb-4 text-sm lg:text-base">
                Créez votre site web professionnel en 2 minutes avec notre IA intégrée. 
                Aucune compétence technique requise.
              </p>
              <div className="text-gray-400 text-sm">
                <p>12100 42e Avenue</p>
                <p>Montréal, QC H1E 2X5, Canada</p>
                <p className="mt-2">
                  <strong>Email:</strong> contact@tovyoapp.com<br />
                  <strong>Tél:</strong> (514) 654-3767
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-white mb-4">Produit</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link to="/#plans" className="hover:text-white transition-colors">Tarifs</Link></li>
                <li><Link to="/demo/restaurant-demo" className="hover:text-white transition-colors">Démo Restaurant</Link></li>
                <li><Link to="/demo/portfolio-demo" className="hover:text-white transition-colors">Démo Portfolio</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-white mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link to="/conditions" className="hover:text-white transition-colors">Conditions d'utilisation</Link></li>
                <li><Link to="/confidentialite" className="hover:text-white transition-colors">Politique de confidentialité</Link></li>
                <li><Link to="/cookies" className="hover:text-white transition-colors">Politique de cookies</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-6 lg:pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <p className="text-gray-400 text-center md:text-left text-sm">
                {t.home.footer}
              </p>
              <div className="flex flex-wrap justify-center space-x-4 lg:space-x-6">
                <Link to="/conditions" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Mentions légales
                </Link>
                <Link to="/confidentialite" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Confidentialité
                </Link>
                <Link to="/cookies" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Cookies
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;