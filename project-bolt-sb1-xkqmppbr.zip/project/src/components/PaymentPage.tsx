import React, { useState, useEffect } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { Globe, ArrowLeft, CreditCard, Check, Shield, Lock, AlertCircle, ExternalLink } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { stripeProducts, getProductByPriceId } from '../stripe-config';
import { createCheckoutSession, createCustomerPortalSession } from '../lib/stripe';
import { supabase } from '../lib/supabase';
import LanguageSelector from './LanguageSelector';

const PaymentPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, refreshUser } = useAuth();
  const { t } = useLanguage();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<string>('');

  const planName = searchParams.get('plan');
  const priceId = searchParams.get('priceId');

  // Redirect if not authenticated
  useEffect(() => {
    if (!user) {
      navigate('/inscription');
    }
  }, [user, navigate]);

  // Get product details or use default plan
  const product = priceId ? getProductByPriceId(priceId) : null;
  const currentPlan = product || stripeProducts[0]; // Default to first plan if no specific plan selected

  useEffect(() => {
    if (currentPlan) {
      setSelectedPlan(currentPlan.name);
    }
  }, [currentPlan]);

  const handlePlanChange = (plan: typeof stripeProducts[0]) => {
    setSelectedPlan(plan.name);
  };

  const handlePayment = async () => {
    if (!selectedPlan || !user) return;

    const selectedProduct = stripeProducts.find(p => p.name === selectedPlan);
    if (!selectedProduct) return;

    setIsProcessing(true);
    setError('');

    try {
      // Get current session
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      // Create checkout session
      const checkoutSession = await createCheckoutSession({
        priceId: selectedProduct.priceId,
        mode: selectedProduct.mode,
        successUrl: `${window.location.origin}/dashboard?payment=success`,
        cancelUrl: `${window.location.origin}/paiement?plan=${encodeURIComponent(selectedPlan)}&priceId=${encodeURIComponent(selectedProduct.priceId)}`,
      });

      // Redirect to Stripe Checkout
      window.location.href = checkoutSession.url;
    } catch (error) {
      console.error('Payment error:', error);
      setError(error instanceof Error ? error.message : 'Une erreur est survenue lors du paiement.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleManageSubscription = async () => {
    if (!user?.customerId) return;

    setIsProcessing(true);
    setError('');

    try {
      const portalSession = await createCustomerPortalSession(user.customerId);
      window.location.href = portalSession.url;
    } catch (error) {
      console.error('Portal error:', error);
      setError(error instanceof Error ? error.message : 'Une erreur est survenue.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!user) {
    return null; // Will redirect in useEffect
  }

  const selectedProduct = stripeProducts.find(p => p.name === selectedPlan) || stripeProducts[0];

  // If user already has an active subscription, show management options
  if (user.hasActiveSubscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        {/* Navigation */}
        <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <Link to="/" className="flex items-center space-x-2">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                  <Globe className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  TovyoApp
                </span>
              </Link>
              
              <div className="flex items-center space-x-4">
                <LanguageSelector />
                <Link
                  to="/dashboard"
                  className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Retour au dashboard</span>
                </Link>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Gérer votre{' '}
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                abonnement
              </span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Vous avez déjà un abonnement actif. Gérez vos paramètres de facturation et d'abonnement.
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
            {/* Current Subscription */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
              <div className="flex items-start space-x-4">
                <Check className="h-8 w-8 text-green-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-green-900 mb-2">
                    Abonnement actif
                  </h3>
                  <p className="text-green-800 mb-4">
                    Vous êtes actuellement abonné au plan <strong>{user.subscriptionPlan}</strong>.
                    Votre abonnement est <strong>{user.subscriptionStatus}</strong>.
                  </p>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-green-700">
                        <strong>Plan :</strong> {user.subscriptionPlan}
                      </p>
                      <p className="text-sm text-green-700">
                        <strong>Statut :</strong> {user.subscriptionStatus}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-green-700">
                        <strong>Compte :</strong> {user.name}
                      </p>
                      <p className="text-sm text-green-700">
                        <strong>Email :</strong> {user.email}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Erreur</p>
                  <p className="text-sm">{error}</p>
                </div>
              </div>
            )}

            {/* Management Options */}
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Options de gestion
                </h3>
                <p className="text-gray-600 mb-6">
                  Utilisez le portail client Stripe pour gérer votre abonnement, mettre à jour vos informations de paiement, 
                  télécharger vos factures ou annuler votre abonnement.
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <div className="flex items-start space-x-4">
                  <Shield className="h-8 w-8 text-blue-600 flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-blue-900 mb-2">Portail client sécurisé</h4>
                    <p className="text-blue-800 mb-4">
                      Accédez à votre portail client Stripe pour :
                    </p>
                    <ul className="text-sm text-blue-700 space-y-1 mb-4">
                      <li>• Mettre à jour vos informations de paiement</li>
                      <li>• Télécharger vos factures</li>
                      <li>• Modifier votre plan d'abonnement</li>
                      <li>• Annuler votre abonnement</li>
                      <li>• Voir l'historique de vos paiements</li>
                    </ul>
                  </div>
                </div>
              </div>

              <button
                onClick={handleManageSubscription}
                disabled={isProcessing || !user.customerId}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-4 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center space-x-2"
              >
                {isProcessing ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Ouverture du portail...</span>
                  </>
                ) : (
                  <>
                    <ExternalLink className="h-5 w-5" />
                    <span>Gérer mon abonnement</span>
                  </>
                )}
              </button>

              <p className="text-xs text-gray-500 text-center">
                Vous serez redirigé vers le portail client sécurisé de Stripe pour gérer votre abonnement.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            
            <div className="flex items-center space-x-4">
              <LanguageSelector />
              <Link
                to="/dashboard"
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Retour au dashboard</span>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Choisissez votre{' '}
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              abonnement
            </span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Sélectionnez le plan qui correspond le mieux à vos besoins et commencez à créer vos sites web professionnels
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Plan Selection */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Nos plans d'abonnement</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {stripeProducts.map((plan) => (
                <div
                  key={plan.id}
                  className={`relative bg-white rounded-2xl p-6 border-2 transition-all duration-300 cursor-pointer hover:shadow-lg ${
                    selectedPlan === plan.name
                      ? 'border-blue-500 shadow-lg shadow-blue-100/50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handlePlanChange(plan)}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                        Le plus populaire
                      </div>
                    </div>
                  )}

                  <div className="text-center mb-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                    <p className="text-gray-600 mb-4">{plan.description}</p>
                    <div className="flex items-center justify-center">
                      <span className="text-4xl font-bold text-gray-900">${plan.price}</span>
                      <span className="text-gray-600 ml-2">/mois</span>
                    </div>
                  </div>

                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {selectedPlan === plan.name && (
                    <div className="absolute top-4 right-4">
                      <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                        <Check className="h-4 w-4 text-white" />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Payment Summary */}
          <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Résumé de commande</h3>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Erreur de paiement</p>
                  <p className="text-sm">{error}</p>
                </div>
              </div>
            )}

            {/* Selected Plan Summary */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <h4 className="font-semibold text-blue-900 mb-2">Plan sélectionné</h4>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium text-blue-800">{selectedProduct.name}</p>
                  <p className="text-sm text-blue-600">{selectedProduct.description}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-blue-900">${selectedProduct.price}</p>
                  <p className="text-sm text-blue-600">par mois</p>
                </div>
              </div>
            </div>

            {/* User Info */}
            <div className="mb-6">
              <h4 className="font-semibold text-gray-900 mb-3">Compte utilisateur</h4>
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-gray-700">
                  <strong>Nom :</strong> {user.name}
                </p>
                <p className="text-gray-700">
                  <strong>Email :</strong> {user.email}
                </p>
              </div>
            </div>

            {/* Security Notice */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
              <div className="flex items-start space-x-3">
                <Lock className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-green-900 mb-1">Paiement sécurisé</h4>
                  <p className="text-sm text-green-700">
                    Paiement traité par Stripe, leader mondial des paiements en ligne. 
                    Vos données sont protégées par un chiffrement de niveau bancaire.
                  </p>
                </div>
              </div>
            </div>

            {/* Guarantee */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <div className="flex items-start space-x-3">
                <Shield className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-blue-900 mb-1">Garantie satisfait ou remboursé</h4>
                  <p className="text-sm text-blue-700">
                    Essayez TovyoApp sans risque pendant 30 jours. 
                    Si vous n'êtes pas satisfait, nous vous remboursons intégralement.
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Button */}
            <button
              onClick={handlePayment}
              disabled={isProcessing}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-4 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center space-x-2"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Redirection vers Stripe...</span>
                </>
              ) : (
                <>
                  <Lock className="h-5 w-5" />
                  <span>Payer ${selectedProduct.price}/mois</span>
                </>
              )}
            </button>

            <p className="text-xs text-gray-500 text-center mt-4">
              En cliquant sur "Payer", vous serez redirigé vers Stripe pour finaliser votre paiement de manière sécurisée.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;