import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle, Globe, ArrowLeft, Clock, Mail, ExternalLink, Copy, Sparkles, Wand2 } from 'lucide-react';

const ThankYouPage = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [copied, setCopied] = useState(false);
  const location = useLocation();
  
  // Récupérer les données du site généré depuis l'état de navigation
  const siteData = location.state || {
    siteName: 'Votre site',
    siteUrl: 'https://votre-site.tovyoapp.com',
    siteId: 'demo-site'
  };

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(siteData.siteUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Erreur lors de la copie:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center px-4">
      <div className={`max-w-4xl mx-auto text-center transition-all duration-1000 transform ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
      }`}>
        {/* Success Animation */}
        <div className="mb-8">
          <div className="relative">
            <div className="inline-flex items-center justify-center w-32 h-32 bg-gradient-to-r from-green-400 to-blue-500 rounded-full shadow-2xl shadow-green-500/25 animate-bounce">
              <CheckCircle className="h-16 w-16 text-white" />
            </div>
            <div className="absolute inset-0 w-32 h-32 bg-gradient-to-r from-green-300 to-blue-400 rounded-full mx-auto animate-ping opacity-20"></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-3xl p-12 shadow-2xl shadow-gray-200/50 border border-gray-100 mb-8">
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            🎉 Site créé avec succès !
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Notre IA a généré <strong>{siteData.siteName}</strong> avec succès !<br />
            Ton site professionnel est maintenant en ligne et prêt à impressionner tes visiteurs.
          </p>

          {/* Site URL Display */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8 border border-blue-200">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Globe className="h-6 w-6 text-blue-600" />
              <h3 className="text-lg font-semibold text-blue-900">Votre site est accessible à :</h3>
            </div>
            
            <div className="bg-white rounded-xl p-4 border border-blue-200 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-blue-600 font-mono text-lg break-all">{siteData.siteUrl}</span>
                <button
                  onClick={copyToClipboard}
                  className="ml-4 p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors flex-shrink-0"
                  title="Copier l'URL"
                >
                  <Copy className="h-5 w-5" />
                </button>
              </div>
              {copied && (
                <p className="text-green-600 text-sm mt-2">✅ URL copiée !</p>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href={siteData.siteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
              >
                <ExternalLink className="h-5 w-5 mr-2" />
                Voir mon site
              </a>
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center justify-center bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold border-2 border-blue-200 hover:bg-blue-50 transition-colors"
              >
                <Copy className="h-5 w-5 mr-2" />
                Copier le lien
              </button>
            </div>
          </div>

          {/* IA Features Showcase */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-100">
              <div className="flex items-center space-x-2 mb-3">
                <Wand2 className="h-6 w-6 text-green-600" />
                <h4 className="font-semibold text-green-900">Généré par IA</h4>
              </div>
              <p className="text-green-700 text-sm">
                Contenu personnalisé, design optimisé et code professionnel créés automatiquement
              </p>
            </div>
            
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl border border-blue-100">
              <div className="flex items-center space-x-2 mb-3">
                <Sparkles className="h-6 w-6 text-blue-600" />
                <h4 className="font-semibold text-blue-900">Prêt pour la production</h4>
              </div>
              <p className="text-blue-700 text-sm">
                Hébergement sécurisé, SSL activé, SEO optimisé et responsive design
              </p>
            </div>
          </div>

          {/* Status Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-10">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-100">
              <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Site en ligne</h3>
              <p className="text-sm text-gray-600">Accessible immédiatement</p>
            </div>
            
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl border border-blue-100">
              <Mail className="h-8 w-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Email envoyé</h3>
              <p className="text-sm text-gray-600">Détails dans votre boîte mail</p>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl border border-purple-100">
              <Globe className="h-8 w-8 text-purple-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">SSL sécurisé</h3>
              <p className="text-sm text-gray-600">Certificat HTTPS activé</p>
            </div>
          </div>

          {/* What was created */}
          <div className="bg-gray-50 rounded-2xl p-6 mb-8 text-left">
            <h3 className="font-semibold text-gray-900 mb-4 text-center">
              🤖 Ce que l'IA a créé pour vous :
            </h3>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Design personnalisé et moderne</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Contenu optimisé pour votre secteur</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Structure SEO professionnelle</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Responsive design (mobile/desktop)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-red-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Performance optimisée</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Hébergement sécurisé inclus</span>
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 group"
            >
              <ArrowLeft className="h-5 w-5 mr-2 group-hover:-translate-x-1 transition-transform" />
              Retour au dashboard
            </Link>
            
            <Link
              to="/formulaire"
              className="inline-flex items-center justify-center bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold border-2 border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all duration-200"
            >
              <Wand2 className="h-5 w-5 mr-2" />
              Créer un autre site
            </Link>
          </div>
        </div>

        {/* Additional Info */}
        <div className="text-center">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 inline-block">
            <h3 className="font-semibold text-blue-900 mb-2">📧 Email de confirmation</h3>
            <p className="text-blue-800 text-sm mb-4">
              Vous avez reçu un email avec tous les détails de votre site
            </p>
            <p className="text-xs text-blue-600">
              Pas d'email ? Vérifiez vos spams ou{' '}
              <Link to="/contact" className="underline hover:text-blue-800">
                contactez-nous
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;