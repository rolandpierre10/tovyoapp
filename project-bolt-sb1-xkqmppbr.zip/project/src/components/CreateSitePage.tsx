import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Globe, ArrowLeft, Send, User, Mail, MessageCircle, Palette, Target, Sparkles, Zap, Code, Wand2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { aiGenerator, SiteGenerationRequest } from '../lib/ai';

const CreateSitePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    email: user?.email || '',
    businessType: '',
    description: '',
    style: 'modern',
    colors: 'blue'
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState('');
  const [progress, setProgress] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      navigate('/connexion');
      return;
    }

    setIsGenerating(true);
    setProgress(0);

    try {
      // Préparer la requête pour l'IA
      const request: SiteGenerationRequest = {
        name: formData.name,
        email: formData.email,
        businessType: formData.businessType,
        description: formData.description,
        style: formData.style,
        colors: formData.colors,
        userId: user.id
      };

      // Simuler les étapes de génération avec progression
      const steps = [
        { message: 'Analyse de vos préférences...', duration: 1000, progress: 15 },
        { message: 'Sélection du template optimal...', duration: 800, progress: 30 },
        { message: 'Génération du contenu par IA...', duration: 1500, progress: 50 },
        { message: 'Application du design personnalisé...', duration: 1000, progress: 70 },
        { message: 'Optimisation mobile et SEO...', duration: 800, progress: 85 },
        { message: 'Configuration de l\'hébergement...', duration: 600, progress: 95 },
        { message: 'Finalisation...', duration: 500, progress: 100 }
      ];

      for (const step of steps) {
        setGenerationStep(step.message);
        setProgress(step.progress);
        await new Promise(resolve => setTimeout(resolve, step.duration));
      }

      // Générer le site avec l'IA
      const generatedSite = await aiGenerator.generateWebsite(request);
      
      // Rediriger vers la page de remerciement avec les détails du site
      navigate('/merci', { 
        state: { 
          siteName: generatedSite.name,
          siteUrl: generatedSite.url,
          siteId: generatedSite.id
        } 
      });

    } catch (error) {
      console.error('Erreur lors de la génération:', error);
      setGenerationStep('Erreur lors de la génération. Veuillez réessayer.');
      setTimeout(() => {
        setIsGenerating(false);
        setProgress(0);
        setGenerationStep('');
      }, 3000);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const businessTypes = [
    'Restaurant / Bar',
    'E-commerce / Boutique',
    'Services professionnels',
    'Créateur / Artiste',
    'Consultant / Coach',
    'Immobilier',
    'Santé / Bien-être',
    'Technologie',
    'Autre'
  ];

  const styles = [
    { value: 'modern', label: 'Moderne & Minimaliste', icon: '✨' },
    { value: 'creative', label: 'Créatif & Artistique', icon: '🎨' },
    { value: 'corporate', label: 'Corporate & Professionnel', icon: '💼' },
    { value: 'playful', label: 'Fun & Coloré', icon: '🌈' }
  ];

  const colorSchemes = [
    { value: 'blue', label: 'Bleu Professionnel', gradient: 'from-blue-500 to-blue-600', preview: '#2563eb' },
    { value: 'green', label: 'Vert Nature', gradient: 'from-green-500 to-green-600', preview: '#059669' },
    { value: 'purple', label: 'Violet Créatif', gradient: 'from-purple-500 to-purple-600', preview: '#7c3aed' },
    { value: 'orange', label: 'Orange Énergique', gradient: 'from-orange-500 to-orange-600', preview: '#ea580c' }
  ];

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center px-4">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-3xl p-12 shadow-2xl shadow-gray-200/50 border border-gray-100">
            {/* Animation IA */}
            <div className="mb-8">
              <div className="relative">
                <div className="w-24 h-24 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                  <Wand2 className="h-12 w-12 text-white animate-spin" style={{ animationDuration: '3s' }} />
                </div>
                <div className="absolute inset-0 w-24 h-24 bg-gradient-to-r from-blue-400 to-indigo-400 rounded-full mx-auto animate-ping opacity-20"></div>
              </div>
            </div>

            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              🤖 IA en action
            </h1>
            
            <p className="text-xl text-gray-600 mb-8">
              Notre intelligence artificielle crée votre site personnalisé...
            </p>

            {/* Barre de progression */}
            <div className="mb-6">
              <div className="bg-gray-200 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 h-full rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-gray-500 mt-2">
                <span>0%</span>
                <span className="font-semibold text-blue-600">{progress}%</span>
                <span>100%</span>
              </div>
            </div>

            {/* Étape actuelle */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
              <div className="flex items-center justify-center space-x-3">
                <Sparkles className="h-5 w-5 text-blue-600 animate-pulse" />
                <span className="text-blue-800 font-medium">{generationStep}</span>
              </div>
            </div>

            {/* Fonctionnalités IA */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-2 text-gray-600">
                <Code className="h-4 w-4 text-green-500" />
                <span>Code optimisé</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>Performance maximale</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Globe className="h-4 w-4 text-blue-500" />
                <span>SEO intégré</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Palette className="h-4 w-4 text-purple-500" />
                <span>Design personnalisé</span>
              </div>
            </div>

            <p className="text-sm text-gray-500 mt-6">
              ⚡ Votre site sera prêt dans quelques instants
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            <Link
              to="/dashboard"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Wand2 className="h-4 w-4" />
            <span>IA Intégrée - Mode Production</span>
          </div>
          
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Créons ton site{' '}
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              parfait
            </span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Notre IA analyse tes préférences et génère automatiquement un site web professionnel unique
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 overflow-hidden">
          <form onSubmit={handleSubmit} className="p-8 lg:p-12">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Informations personnelles */}
              <div className="space-y-6">
                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                    <User className="h-4 w-4" />
                    <span>Nom de ton entreprise/projet</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    placeholder="ex: Mon Restaurant"
                  />
                </div>

                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                    <Mail className="h-4 w-4" />
                    <span>Ton email</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                    placeholder="ton@email.com"
                  />
                </div>

                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                    <Target className="h-4 w-4" />
                    <span>Type d'activité</span>
                  </label>
                  <select
                    name="businessType"
                    value={formData.businessType}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                  >
                    <option value="">Sélectionne ton secteur</option>
                    {businessTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Informations business */}
              <div className="space-y-6">
                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                    <MessageCircle className="h-4 w-4" />
                    <span>Décris ton activité</span>
                    <span className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded-full">IA analysera</span>
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                    placeholder="ex: Je suis photographe spécialisée dans les mariages. J'ai besoin d'un site pour présenter mon portfolio et permettre aux clients de me contacter..."
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    💡 Plus tu donnes de détails, plus l'IA pourra personnaliser ton site
                  </p>
                </div>

                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                    <Palette className="h-4 w-4" />
                    <span>Style préféré</span>
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {styles.map(style => (
                      <label key={style.value} className="relative cursor-pointer">
                        <input
                          type="radio"
                          name="style"
                          value={style.value}
                          checked={formData.style === style.value}
                          onChange={handleChange}
                          className="sr-only"
                        />
                        <div className={`p-4 border-2 rounded-xl text-center text-sm font-medium transition-all duration-200 ${
                          formData.style === style.value
                            ? 'border-blue-500 bg-blue-50 text-blue-700'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}>
                          <div className="text-2xl mb-2">{style.icon}</div>
                          {style.label}
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Couleurs principales */}
            <div className="mt-8">
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-4">
                <Palette className="h-4 w-4" />
                <span>Couleurs principales</span>
              </label>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {colorSchemes.map(color => (
                  <label key={color.value} className="relative cursor-pointer">
                    <input
                      type="radio"
                      name="colors"
                      value={color.value}
                      checked={formData.colors === color.value}
                      onChange={handleChange}
                      className="sr-only"
                    />
                    <div className={`p-4 border-2 rounded-xl text-center transition-all duration-200 ${
                      formData.colors === color.value
                        ? 'border-gray-400 ring-2 ring-gray-300'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <div 
                        className="w-12 h-12 rounded-lg mx-auto mb-2"
                        style={{ backgroundColor: color.preview }}
                      ></div>
                      <span className="text-sm font-medium text-gray-700">{color.label}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* IA Features */}
            <div className="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200">
              <div className="flex items-center space-x-2 mb-4">
                <Wand2 className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-blue-900">Ce que notre IA va créer pour toi :</h3>
              </div>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-2 text-blue-700">
                  <Sparkles className="h-4 w-4" />
                  <span>Contenu personnalisé et optimisé</span>
                </div>
                <div className="flex items-center space-x-2 text-blue-700">
                  <Code className="h-4 w-4" />
                  <span>Code propre et performant</span>
                </div>
                <div className="flex items-center space-x-2 text-blue-700">
                  <Globe className="h-4 w-4" />
                  <span>SEO automatiquement optimisé</span>
                </div>
                <div className="flex items-center space-x-2 text-blue-700">
                  <Zap className="h-4 w-4" />
                  <span>Design responsive et moderne</span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="mt-12 text-center">
              <button
                type="submit"
                disabled={isGenerating}
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-12 py-4 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                <Wand2 className="h-5 w-5" />
                <span>Lancer la génération IA</span>
              </button>
              
              <p className="text-sm text-gray-500 mt-4">
                🤖 L'IA créera ton site en moins de 2 minutes
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateSitePage;