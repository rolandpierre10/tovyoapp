import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, ArrowLeft, FileText, Calendar } from 'lucide-react';

const TermsPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 lg:p-12">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Conditions d'utilisation
            </h1>
            <div className="flex items-center justify-center space-x-2 text-gray-600">
              <Calendar className="h-4 w-4" />
              <span>Dernière mise à jour : 9 décembre 2024</span>
            </div>
          </div>

          {/* Content */}
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Acceptation des conditions</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                En accédant et en utilisant TovyoApp, vous acceptez d'être lié par ces conditions d'utilisation. 
                Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser notre service.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Description du service</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                TovyoApp est une plateforme de création de sites web qui utilise l'intelligence artificielle 
                pour générer automatiquement des sites web professionnels. Notre service inclut :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Création automatique de sites web par IA</li>
                <li>Hébergement sécurisé</li>
                <li>Certificats SSL gratuits</li>
                <li>Support technique</li>
                <li>Outils de personnalisation</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Compte utilisateur</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Pour utiliser TovyoApp, vous devez créer un compte en fournissant des informations exactes et complètes. 
                Vous êtes responsable de :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Maintenir la confidentialité de vos identifiants</li>
                <li>Toutes les activités qui se produisent sous votre compte</li>
                <li>Nous notifier immédiatement de toute utilisation non autorisée</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Utilisation acceptable</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Vous vous engagez à ne pas utiliser TovyoApp pour :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Créer du contenu illégal, diffamatoire ou offensant</li>
                <li>Violer les droits de propriété intellectuelle</li>
                <li>Distribuer des logiciels malveillants ou du spam</li>
                <li>Tenter d'accéder non autorisé à nos systèmes</li>
                <li>Utiliser le service à des fins frauduleuses</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Propriété intellectuelle</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                TovyoApp et ses contenus sont protégés par les lois sur la propriété intellectuelle. 
                Vous conservez la propriété du contenu que vous créez, mais accordez à TovyoApp 
                une licence pour héberger et afficher ce contenu.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Paiements et remboursements</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Les abonnements sont facturés mensuellement. Nous offrons une garantie de remboursement 
                de 30 jours pour les nouveaux abonnements. Les remboursements sont traités dans un délai 
                de 5-10 jours ouvrables.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Résiliation</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Vous pouvez résilier votre compte à tout moment. Nous nous réservons le droit de 
                suspendre ou résilier votre compte en cas de violation de ces conditions.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Limitation de responsabilité</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                TovyoApp est fourni "en l'état". Nous ne garantissons pas que le service sera 
                ininterrompu ou exempt d'erreurs. Notre responsabilité est limitée au montant 
                payé pour le service au cours des 12 derniers mois.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Modifications</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous nous réservons le droit de modifier ces conditions à tout moment. 
                Les modifications importantes seront notifiées par email 30 jours à l'avance.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Contact</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Pour toute question concernant ces conditions d'utilisation, contactez-nous :
              </p>
              <div className="bg-gray-50 p-4 rounded-xl">
                <p className="text-gray-700">
                  <strong>Email :</strong> contact@tovyoapp.com<br />
                  <strong>Téléphone :</strong> (514) 654-3767<br />
                  <strong>Adresse :</strong> 12100 42e Avenue, Montréal, QC H1E 2X5, Canada
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;