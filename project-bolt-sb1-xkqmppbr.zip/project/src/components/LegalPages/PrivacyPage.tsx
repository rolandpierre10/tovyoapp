import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, ArrowLeft, Shield, Calendar } from 'lucide-react';

const PrivacyPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 lg:p-12">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="bg-green-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Shield className="h-8 w-8 text-green-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Politique de confidentialité
            </h1>
            <div className="flex items-center justify-center space-x-2 text-gray-600">
              <Calendar className="h-4 w-4" />
              <span>Dernière mise à jour : 9 décembre 2024</span>
            </div>
          </div>

          {/* Content */}
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Introduction</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Chez TovyoApp, nous respectons votre vie privée et nous nous engageons à protéger 
                vos données personnelles. Cette politique explique comment nous collectons, utilisons 
                et protégeons vos informations.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Informations que nous collectons</h2>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Informations que vous nous fournissez :</h3>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Nom et adresse email lors de l'inscription</li>
                <li>Informations de paiement (traitées par Stripe)</li>
                <li>Contenu que vous créez sur votre site web</li>
                <li>Communications avec notre support</li>
              </ul>

              <h3 className="text-xl font-semibold text-gray-900 mb-3">Informations collectées automatiquement :</h3>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Adresse IP et informations de l'appareil</li>
                <li>Données d'utilisation et de navigation</li>
                <li>Cookies et technologies similaires</li>
                <li>Journaux de serveur</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Comment nous utilisons vos informations</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous utilisons vos informations pour :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Fournir et améliorer nos services</li>
                <li>Créer et gérer votre compte</li>
                <li>Traiter les paiements et facturer</li>
                <li>Fournir un support client</li>
                <li>Envoyer des communications importantes</li>
                <li>Analyser l'utilisation pour améliorer notre plateforme</li>
                <li>Respecter nos obligations légales</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Partage de vos informations</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous ne vendons jamais vos données personnelles. Nous pouvons partager vos informations avec :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li><strong>Prestataires de services :</strong> Stripe pour les paiements, Supabase pour l'hébergement</li>
                <li><strong>Obligations légales :</strong> Si requis par la loi ou pour protéger nos droits</li>
                <li><strong>Transfert d'entreprise :</strong> En cas de fusion ou acquisition</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Sécurité des données</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous mettons en place des mesures de sécurité appropriées pour protéger vos données :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Chiffrement SSL/TLS pour toutes les transmissions</li>
                <li>Authentification sécurisée</li>
                <li>Accès limité aux données personnelles</li>
                <li>Surveillance continue de la sécurité</li>
                <li>Sauvegardes régulières et sécurisées</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Vos droits</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Conformément aux lois applicables, vous avez le droit de :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li><strong>Accès :</strong> Demander une copie de vos données personnelles</li>
                <li><strong>Rectification :</strong> Corriger des informations inexactes</li>
                <li><strong>Suppression :</strong> Demander la suppression de vos données</li>
                <li><strong>Portabilité :</strong> Recevoir vos données dans un format structuré</li>
                <li><strong>Opposition :</strong> Vous opposer au traitement de vos données</li>
                <li><strong>Limitation :</strong> Demander la limitation du traitement</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Cookies et technologies de suivi</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous utilisons des cookies pour améliorer votre expérience. Types de cookies utilisés :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li><strong>Essentiels :</strong> Nécessaires au fonctionnement du site</li>
                <li><strong>Fonctionnels :</strong> Mémorisation de vos préférences</li>
                <li><strong>Analytiques :</strong> Compréhension de l'utilisation du site</li>
                <li><strong>Marketing :</strong> Personnalisation du contenu (avec votre consentement)</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Conservation des données</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous conservons vos données personnelles aussi longtemps que nécessaire pour :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Fournir nos services</li>
                <li>Respecter nos obligations légales</li>
                <li>Résoudre les litiges</li>
                <li>Faire respecter nos accords</li>
              </ul>
              <p className="text-gray-700 leading-relaxed mb-4">
                Après suppression de votre compte, nous conservons certaines données pendant 3 ans 
                pour des raisons légales et de sécurité.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Transferts internationaux</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Vos données peuvent être transférées et traitées dans des pays autres que le Canada. 
                Nous nous assurons que ces transferts respectent les lois applicables sur la protection des données.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Modifications de cette politique</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous pouvons mettre à jour cette politique de confidentialité. Les modifications importantes 
                seront notifiées par email 30 jours à l'avance.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Contact</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Pour toute question concernant cette politique de confidentialité ou pour exercer vos droits :
              </p>
              <div className="bg-gray-50 p-4 rounded-xl">
                <p className="text-gray-700">
                  <strong>Email :</strong> contact@tovyoapp.com<br />
                  <strong>Téléphone :</strong> (514) 654-3767<br />
                  <strong>Adresse :</strong> 12100 42e Avenue, Montréal, QC H1E 2X5, Canada
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPage;