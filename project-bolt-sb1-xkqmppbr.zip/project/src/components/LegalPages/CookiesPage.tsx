import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, ArrowLeft, Cookie, Calendar } from 'lucide-react';

const CookiesPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 lg:p-12">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="bg-orange-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Cookie className="h-8 w-8 text-orange-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Politique de cookies
            </h1>
            <div className="flex items-center justify-center space-x-2 text-gray-600">
              <Calendar className="h-4 w-4" />
              <span>Dernière mise à jour : 9 décembre 2024</span>
            </div>
          </div>

          {/* Content */}
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Qu'est-ce qu'un cookie ?</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Un cookie est un petit fichier texte stocké sur votre appareil (ordinateur, tablette, smartphone) 
                lorsque vous visitez un site web. Les cookies permettent au site de mémoriser vos actions et 
                préférences pendant une période donnée.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Comment nous utilisons les cookies</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                TovyoApp utilise des cookies pour améliorer votre expérience utilisateur, analyser l'utilisation 
                de notre site et personnaliser le contenu. Nous utilisons les cookies pour :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li>Maintenir votre session de connexion</li>
                <li>Mémoriser vos préférences (langue, thème)</li>
                <li>Analyser le trafic et l'utilisation du site</li>
                <li>Améliorer la sécurité</li>
                <li>Personnaliser votre expérience</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Types de cookies que nous utilisons</h2>
              
              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-xl">
                  <h3 className="text-xl font-semibold text-blue-900 mb-3">Cookies strictement nécessaires</h3>
                  <p className="text-blue-800 mb-3">
                    Ces cookies sont essentiels au fonctionnement de notre site web. Ils ne peuvent pas être désactivés.
                  </p>
                  <ul className="list-disc list-inside text-blue-700 space-y-1">
                    <li>Cookies de session d'authentification</li>
                    <li>Cookies de sécurité CSRF</li>
                    <li>Cookies de préférences de langue</li>
                  </ul>
                </div>

                <div className="bg-green-50 p-6 rounded-xl">
                  <h3 className="text-xl font-semibold text-green-900 mb-3">Cookies fonctionnels</h3>
                  <p className="text-green-800 mb-3">
                    Ces cookies permettent d'améliorer les fonctionnalités et la personnalisation du site.
                  </p>
                  <ul className="list-disc list-inside text-green-700 space-y-1">
                    <li>Préférences utilisateur (thème, mise en page)</li>
                    <li>Paramètres de compte</li>
                    <li>Historique de navigation</li>
                  </ul>
                </div>

                <div className="bg-purple-50 p-6 rounded-xl">
                  <h3 className="text-xl font-semibold text-purple-900 mb-3">Cookies analytiques</h3>
                  <p className="text-purple-800 mb-3">
                    Ces cookies nous aident à comprendre comment vous utilisez notre site pour l'améliorer.
                  </p>
                  <ul className="list-disc list-inside text-purple-700 space-y-1">
                    <li>Google Analytics (anonymisé)</li>
                    <li>Statistiques d'utilisation</li>
                    <li>Mesure de performance</li>
                  </ul>
                </div>

                <div className="bg-orange-50 p-6 rounded-xl">
                  <h3 className="text-xl font-semibold text-orange-900 mb-3">Cookies de marketing</h3>
                  <p className="text-orange-800 mb-3">
                    Ces cookies sont utilisés pour personnaliser les publicités et mesurer leur efficacité.
                  </p>
                  <ul className="list-disc list-inside text-orange-700 space-y-1">
                    <li>Suivi des conversions</li>
                    <li>Personnalisation du contenu</li>
                    <li>Remarketing (avec votre consentement)</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Cookies tiers</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous utilisons également des services tiers qui peuvent placer des cookies sur votre appareil :
              </p>
              
              <div className="bg-gray-50 p-6 rounded-xl mb-4">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Services tiers utilisés :</h3>
                <ul className="space-y-3">
                  <li className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Google Analytics</span>
                    <span className="text-sm text-gray-600">Analyse du trafic</span>
                  </li>
                  <li className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Stripe</span>
                    <span className="text-sm text-gray-600">Traitement des paiements</span>
                  </li>
                  <li className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Supabase</span>
                    <span className="text-sm text-gray-600">Authentification et base de données</span>
                  </li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Durée de conservation</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                La durée de conservation des cookies varie selon leur type :
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li><strong>Cookies de session :</strong> Supprimés à la fermeture du navigateur</li>
                <li><strong>Cookies persistants :</strong> Conservés de 30 jours à 2 ans maximum</li>
                <li><strong>Cookies analytiques :</strong> Conservés 26 mois (Google Analytics)</li>
                <li><strong>Cookies fonctionnels :</strong> Conservés 1 an maximum</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Gestion de vos préférences</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Vous pouvez contrôler et gérer les cookies de plusieurs façons :
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-3">Via notre bannière de cookies :</h3>
              <p className="text-gray-700 leading-relaxed mb-4">
                Lors de votre première visite, une bannière vous permet de choisir quels types de cookies accepter.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-3">Via les paramètres de votre navigateur :</h3>
              <ul className="list-disc list-inside text-gray-700 space-y-2 mb-4">
                <li><strong>Chrome :</strong> Paramètres → Confidentialité et sécurité → Cookies</li>
                <li><strong>Firefox :</strong> Paramètres → Vie privée et sécurité → Cookies</li>
                <li><strong>Safari :</strong> Préférences → Confidentialité → Cookies</li>
                <li><strong>Edge :</strong> Paramètres → Cookies et autorisations de site</li>
              </ul>

              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-xl">
                <p className="text-yellow-800 text-sm">
                  <strong>Note :</strong> La désactivation de certains cookies peut affecter le fonctionnement 
                  de notre site web et réduire la qualité de votre expérience utilisateur.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Cookies et données personnelles</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Certains cookies peuvent contenir des données personnelles. Ces données sont traitées conformément 
                à notre <Link to="/confidentialite" className="text-blue-600 hover:text-blue-700 underline">
                Politique de confidentialité</Link>.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Modifications de cette politique</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Nous pouvons mettre à jour cette politique de cookies pour refléter les changements dans nos 
                pratiques ou pour d'autres raisons opérationnelles, légales ou réglementaires.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Contact</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Pour toute question concernant notre utilisation des cookies :
              </p>
              <div className="bg-gray-50 p-4 rounded-xl">
                <p className="text-gray-700">
                  <strong>Email :</strong> contact@tovyoapp.com<br />
                  <strong>Adresse :</strong> 12100 42e Avenue, Montréal, QC H1E 2X5, Canada
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookiesPage;