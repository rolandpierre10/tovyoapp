import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Globe, 
  Users, 
  CreditCard, 
  BarChart3, 
  Settings, 
  LogOut, 
  Search, 
  Filter, 
  Download,
  Eye,
  Edit,
  Trash2,
  Plus,
  CheckCircle,
  XCircle,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Clock,
  Shield,
  Database,
  Activity,
  Send,
  User,
  MessageCircle,
  Palette,
  Target,
  ExternalLink,
  Code,
  Zap,
  Home
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface User {
  id: string;
  email: string;
  full_name: string;
  role: string;
  created_at: string;
  hasActiveSubscription: boolean;
  subscriptionPlan?: string;
  subscriptionStatus?: string;
}

interface Subscription {
  id: number;
  customer_id: string;
  subscription_id: string;
  price_id: string;
  status: string;
  current_period_start: number;
  current_period_end: number;
  cancel_at_period_end: boolean;
  created_at: string;
  user_email?: string;
  user_name?: string;
}

interface Stats {
  totalUsers: number;
  activeSubscriptions: number;
  totalRevenue: number;
  newUsersThisMonth: number;
  churnRate: number;
  averageRevenuePerUser: number;
}

interface AdminSite {
  id: string;
  name: string;
  type: 'demo' | 'test' | 'personal';
  url: string;
  description: string;
  status: 'active' | 'inactive';
  created_at: string;
  visits: number;
}

const AdminDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [users, setUsers] = useState<User[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [adminSites, setAdminSites] = useState<AdminSite[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    activeSubscriptions: 0,
    totalRevenue: 0,
    newUsersThisMonth: 0,
    churnRate: 0,
    averageRevenuePerUser: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showCreateSiteModal, setShowCreateSiteModal] = useState(false);
  const [isCreatingSite, setIsCreatingSite] = useState(false);
  const [newSiteData, setNewSiteData] = useState({
    name: '',
    type: 'demo' as 'demo' | 'test' | 'personal',
    description: '',
    businessType: 'restaurant',
    style: 'modern',
    colors: 'blue'
  });

  // Vérifier si l'utilisateur est admin
  useEffect(() => {
    if (!user || user.email !== 'admin@tovyoapp.com') {
      navigate('/');
    }
  }, [user, navigate]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadUsers(),
        loadSubscriptions(),
        loadStats(),
        loadAdminSites()
      ]);
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    const { data: profiles, error } = await supabase
      .from('profiles')
      .select(`
        id,
        email,
        full_name,
        role,
        created_at
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading users:', error);
      return;
    }

    // Enrichir avec les données d'abonnement
    const enrichedUsers = await Promise.all(
      profiles.map(async (profile) => {
        const { data: subscription } = await supabase
          .from('stripe_user_subscriptions')
          .select('*')
          .eq('customer_id', profile.id)
          .single();

        return {
          ...profile,
          hasActiveSubscription: subscription?.subscription_status === 'active',
          subscriptionPlan: subscription?.price_id ? getPlanNameFromPriceId(subscription.price_id) : undefined,
          subscriptionStatus: subscription?.subscription_status
        };
      })
    );

    setUsers(enrichedUsers);
  };

  const loadSubscriptions = async () => {
    const { data, error } = await supabase
      .from('stripe_subscriptions')
      .select(`
        *,
        stripe_customers!inner(
          user_id,
          profiles!inner(
            email,
            full_name
          )
        )
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading subscriptions:', error);
      return;
    }

    const enrichedSubscriptions = data.map(sub => ({
      ...sub,
      user_email: sub.stripe_customers?.profiles?.email,
      user_name: sub.stripe_customers?.profiles?.full_name
    }));

    setSubscriptions(enrichedSubscriptions);
  };

  const loadStats = async () => {
    try {
      // Total des utilisateurs
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Abonnements actifs
      const { count: activeSubscriptions } = await supabase
        .from('stripe_subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Nouveaux utilisateurs ce mois
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { count: newUsersThisMonth } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', startOfMonth.toISOString());

      // Calculs de revenus (simulation)
      const totalRevenue = (activeSubscriptions || 0) * 29.99; // Prix moyen
      const averageRevenuePerUser = totalUsers ? totalRevenue / totalUsers : 0;
      const churnRate = 5.2; // Simulation

      setStats({
        totalUsers: totalUsers || 0,
        activeSubscriptions: activeSubscriptions || 0,
        totalRevenue,
        newUsersThisMonth: newUsersThisMonth || 0,
        churnRate,
        averageRevenuePerUser
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const loadAdminSites = async () => {
    // Simuler des sites admin pour la démo
    const mockSites: AdminSite[] = [
      {
        id: '1',
        name: 'Restaurant Demo',
        type: 'demo',
        url: 'restaurant-demo',
        description: 'Site de démonstration pour restaurants',
        status: 'active',
        created_at: '2024-01-15T10:00:00Z',
        visits: 1250
      },
      {
        id: '2',
        name: 'Portfolio Demo',
        type: 'demo',
        url: 'portfolio-demo',
        description: 'Site de démonstration pour portfolios',
        status: 'active',
        created_at: '2024-01-20T14:30:00Z',
        visits: 890
      },
      {
        id: '3',
        name: 'E-commerce Demo',
        type: 'demo',
        url: 'ecommerce-demo',
        description: 'Site de démonstration pour boutiques en ligne',
        status: 'active',
        created_at: '2024-02-01T09:15:00Z',
        visits: 2156
      },
      {
        id: '4',
        name: 'Test E-commerce',
        type: 'test',
        url: 'test-ecommerce',
        description: 'Site de test pour fonctionnalités e-commerce',
        status: 'active',
        created_at: '2024-02-01T09:15:00Z',
        visits: 156
      }
    ];
    setAdminSites(mockSites);
  };

  const getPlanNameFromPriceId = (priceId: string): string => {
    const priceMap: Record<string, string> = {
      'price_1RXTq4DcUBznaKKpaYSyGQG3': 'Starter',
      'price_1RXTohDcUBznaKKpLkvOQyYB': 'Pro',
    };
    return priceMap[priceId] || 'Unknown';
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleCreateSite = async () => {
    setIsCreatingSite(true);
    
    try {
      // Simuler la création d'un site
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const newSite: AdminSite = {
        id: Date.now().toString(),
        name: newSiteData.name,
        type: newSiteData.type,
        url: newSiteData.name.toLowerCase().replace(/\s+/g, '-'),
        description: newSiteData.description,
        status: 'active',
        created_at: new Date().toISOString(),
        visits: 0
      };

      setAdminSites(prev => [newSite, ...prev]);
      setShowCreateSiteModal(false);
      setNewSiteData({
        name: '',
        type: 'demo',
        description: '',
        businessType: 'restaurant',
        style: 'modern',
        colors: 'blue'
      });
    } catch (error) {
      console.error('Error creating site:', error);
    } finally {
      setIsCreatingSite(false);
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.full_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterStatus === 'all') return matchesSearch;
    if (filterStatus === 'active') return matchesSearch && user.hasActiveSubscription;
    if (filterStatus === 'inactive') return matchesSearch && !user.hasActiveSubscription;
    
    return matchesSearch;
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (!user || user.email !== 'admin@tovyoapp.com') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-red-600 to-red-700 p-2 rounded-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold text-gray-900">Admin Dashboard</span>
                <div className="text-sm text-gray-500">TovyoApp</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link
                to="/"
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors px-3 py-2 rounded-lg hover:bg-gray-100"
              >
                <Home className="h-5 w-5" />
                <span>Revenir à l'accueil</span>
              </Link>
              <div className="flex items-center space-x-2 text-gray-700">
                <Shield className="h-5 w-5" />
                <span className="font-medium">Administrateur</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Déconnexion</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {[
                { id: 'overview', name: 'Vue d\'ensemble', icon: BarChart3 },
                { id: 'sites', name: 'Mes Sites', icon: Globe },
                { id: 'users', name: 'Utilisateurs', icon: Users },
                { id: 'subscriptions', name: 'Abonnements', icon: CreditCard },
                { id: 'analytics', name: 'Analytics', icon: TrendingUp },
                { id: 'settings', name: 'Paramètres', icon: Settings }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-red-500 text-red-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-5 w-5" />
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Utilisateurs totaux</p>
                    <p className="text-3xl font-bold text-gray-900">{stats.totalUsers}</p>
                    <p className="text-sm text-green-600">+{stats.newUsersThisMonth} ce mois</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Sites admin</p>
                    <p className="text-3xl font-bold text-gray-900">{adminSites.length}</p>
                    <p className="text-sm text-gray-500">Démos et tests</p>
                  </div>
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <Globe className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Abonnements actifs</p>
                    <p className="text-3xl font-bold text-gray-900">{stats.activeSubscriptions}</p>
                    <p className="text-sm text-gray-500">
                      {((stats.activeSubscriptions / stats.totalUsers) * 100).toFixed(1)}% conversion
                    </p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-lg">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Revenus totaux</p>
                    <p className="text-3xl font-bold text-gray-900">{formatCurrency(stats.totalRevenue)}</p>
                    <p className="text-sm text-green-600">+12% ce mois</p>
                  </div>
                  <div className="bg-yellow-100 p-3 rounded-lg">
                    <DollarSign className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Nouveaux utilisateurs</h3>
                <div className="space-y-4">
                  {users.slice(0, 5).map((user) => (
                    <div key={user.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{user.full_name || 'Utilisateur'}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </div>
                      <span className="text-sm text-gray-500">{formatDate(user.created_at)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Sites récents</h3>
                <div className="space-y-4">
                  {adminSites.slice(0, 5).map((site) => (
                    <div key={site.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                          <Globe className="h-4 w-4 text-purple-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{site.name}</p>
                          <p className="text-sm text-gray-500">{site.type} - {site.visits} visites</p>
                        </div>
                      </div>
                      <span className="text-sm text-gray-500">{formatDate(site.created_at)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Sites Tab */}
        {activeTab === 'sites' && (
          <div className="space-y-6">
            {/* Header with Create Button */}
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Mes Sites</h2>
                <p className="text-gray-600">Gérer vos sites de démonstration, test et usage personnel</p>
              </div>
              <button
                onClick={() => setShowCreateSiteModal(true)}
                className="flex items-center space-x-2 bg-red-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-red-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>Créer un site</span>
              </button>
            </div>

            {/* Sites Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {adminSites.map((site) => (
                <div key={site.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${
                        site.type === 'demo' ? 'bg-blue-100' :
                        site.type === 'test' ? 'bg-yellow-100' : 'bg-green-100'
                      }`}>
                        <Globe className={`h-5 w-5 ${
                          site.type === 'demo' ? 'text-blue-600' :
                          site.type === 'test' ? 'text-yellow-600' : 'text-green-600'
                        }`} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{site.name}</h3>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          site.type === 'demo' ? 'bg-blue-100 text-blue-800' :
                          site.type === 'test' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {site.type === 'demo' ? 'Démo' : site.type === 'test' ? 'Test' : 'Personnel'}
                        </span>
                      </div>
                    </div>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      site.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {site.status === 'active' ? 'Actif' : 'Inactif'}
                    </span>
                  </div>

                  <p className="text-gray-600 text-sm mb-4">{site.description}</p>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-1">
                      <BarChart3 className="h-4 w-4" />
                      <span>{site.visits} visites</span>
                    </div>
                    <span>{formatDate(site.created_at)}</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Link
                      to={`/demo/${site.url}`}
                      className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium text-center text-sm flex items-center justify-center space-x-1"
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span>Voir</span>
                    </Link>
                    <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button className="p-2 text-red-400 hover:text-red-600 transition-colors">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            {/* Search and Filters */}
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Rechercher un utilisateur..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  <option value="all">Tous les utilisateurs</option>
                  <option value="active">Abonnés actifs</option>
                  <option value="inactive">Non abonnés</option>
                </select>
                <button className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">
                  <Download className="h-4 w-4" />
                  <span>Exporter</span>
                </button>
              </div>
            </div>

            {/* Users Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Utilisateur
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Abonnement
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date d'inscription
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Statut
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <Users className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {user.full_name || 'Utilisateur'}
                              </div>
                              <div className="text-sm text-gray-500">{user.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {user.hasActiveSubscription ? (
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {user.subscriptionPlan}
                              </div>
                              <div className="text-sm text-gray-500">{user.subscriptionStatus}</div>
                            </div>
                          ) : (
                            <span className="text-sm text-gray-500">Aucun abonnement</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(user.created_at)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {user.hasActiveSubscription ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Actif
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                              <XCircle className="h-3 w-3 mr-1" />
                              Inactif
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <button className="text-blue-600 hover:text-blue-900">
                              <Eye className="h-4 w-4" />
                            </button>
                            <button className="text-gray-600 hover:text-gray-900">
                              <Edit className="h-4 w-4" />
                            </button>
                            <button className="text-red-600 hover:text-red-900">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Subscriptions Tab */}
        {activeTab === 'subscriptions' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Gestion des abonnements</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Client
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Plan
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Statut
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Période
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {subscriptions.map((subscription) => (
                      <tr key={subscription.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {subscription.user_name}
                            </div>
                            <div className="text-sm text-gray-500">{subscription.user_email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {getPlanNameFromPriceId(subscription.price_id)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            subscription.status === 'active' 
                              ? 'bg-green-100 text-green-800'
                              : subscription.status === 'canceled'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {subscription.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(subscription.current_period_start * 1000).toLocaleDateString()} - 
                          {new Date(subscription.current_period_end * 1000).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center space-x-2">
                            <button className="text-blue-600 hover:text-blue-900">
                              <Eye className="h-4 w-4" />
                            </button>
                            <button className="text-gray-600 hover:text-gray-900">
                              <Edit className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Croissance des utilisateurs</h3>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2" />
                    <p>Graphique de croissance</p>
                    <p className="text-sm">(Intégration avec Chart.js à venir)</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenus mensuels</h3>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <DollarSign className="h-12 w-12 mx-auto mb-2" />
                    <p>Graphique des revenus</p>
                    <p className="text-sm">(Intégration avec Chart.js à venir)</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Métriques détaillées</h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">{stats.averageRevenuePerUser.toFixed(2)}$</div>
                  <div className="text-sm text-gray-500">ARPU (Revenu moyen par utilisateur)</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">
                    {((stats.activeSubscriptions / stats.totalUsers) * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-500">Taux de conversion</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">
                    {(stats.totalRevenue / 12).toFixed(0)}$
                  </div>
                  <div className="text-sm text-gray-500">MRR (Revenus récurrents mensuels)</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Configuration générale</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nom de l'application
                    </label>
                    <input
                      type="text"
                      defaultValue="TovyoApp"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email de support
                    </label>
                    <input
                      type="email"
                      defaultValue="support@tovyoapp.com"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>
                  <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">
                    Sauvegarder
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Sécurité</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-gray-900">Authentification à deux facteurs</div>
                      <div className="text-sm text-gray-500">Sécurité renforcée pour les admins</div>
                    </div>
                    <button className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      Activé
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-gray-900">Logs d'audit</div>
                      <div className="text-sm text-gray-500">Traçabilité des actions admin</div>
                    </div>
                    <button className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      Activé
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Base de données</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <button className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                  <Database className="h-5 w-5" />
                  <span>Backup</span>
                </button>
                <button className="flex items-center justify-center space-x-2 bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700 transition-colors">
                  <Activity className="h-5 w-5" />
                  <span>Monitoring</span>
                </button>
                <button className="flex items-center justify-center space-x-2 bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700 transition-colors">
                  <Settings className="h-5 w-5" />
                  <span>Maintenance</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Create Site Modal */}
      {showCreateSiteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Créer un nouveau site</h2>
                <button
                  onClick={() => setShowCreateSiteModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XCircle className="h-6 w-6" />
                </button>
              </div>

              <form onSubmit={(e) => { e.preventDefault(); handleCreateSite(); }} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                      <Globe className="h-4 w-4" />
                      <span>Nom du site</span>
                    </label>
                    <input
                      type="text"
                      value={newSiteData.name}
                      onChange={(e) => setNewSiteData(prev => ({ ...prev, name: e.target.value }))}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="ex: Mon Site Demo"
                    />
                  </div>

                  <div>
                    <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                      <Target className="h-4 w-4" />
                      <span>Type de site</span>
                    </label>
                    <select
                      value={newSiteData.type}
                      onChange={(e) => setNewSiteData(prev => ({ ...prev, type: e.target.value as 'demo' | 'test' | 'personal' }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="demo">Démonstration</option>
                      <option value="test">Test</option>
                      <option value="personal">Personnel</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                    <MessageCircle className="h-4 w-4" />
                    <span>Description</span>
                  </label>
                  <textarea
                    value={newSiteData.description}
                    onChange={(e) => setNewSiteData(prev => ({ ...prev, description: e.target.value }))}
                    required
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                    placeholder="Décrivez l'objectif de ce site..."
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                      <Target className="h-4 w-4" />
                      <span>Type d'activité</span>
                    </label>
                    <select
                      value={newSiteData.businessType}
                      onChange={(e) => setNewSiteData(prev => ({ ...prev, businessType: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="restaurant">Restaurant / Bar</option>
                      <option value="ecommerce">E-commerce / Boutique</option>
                      <option value="services">Services professionnels</option>
                      <option value="creative">Créateur / Artiste</option>
                      <option value="consultant">Consultant / Coach</option>
                      <option value="realEstate">Immobilier</option>
                      <option value="health">Santé / Bien-être</option>
                      <option value="technology">Technologie</option>
                      <option value="other">Autre</option>
                    </select>
                  </div>

                  <div>
                    <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                      <Palette className="h-4 w-4" />
                      <span>Style</span>
                    </label>
                    <select
                      value={newSiteData.style}
                      onChange={(e) => setNewSiteData(prev => ({ ...prev, style: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="modern">Moderne & Minimaliste</option>
                      <option value="creative">Créatif & Artistique</option>
                      <option value="corporate">Corporate & Professionnel</option>
                      <option value="playful">Fun & Coloré</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-4">
                    <Palette className="h-4 w-4" />
                    <span>Couleurs principales</span>
                  </label>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { value: 'blue', label: 'Bleu Professionnel', gradient: 'from-blue-500 to-blue-600' },
                      { value: 'green', label: 'Vert Nature', gradient: 'from-green-500 to-green-600' },
                      { value: 'purple', label: 'Violet Créatif', gradient: 'from-purple-500 to-purple-600' },
                      { value: 'orange', label: 'Orange Énergique', gradient: 'from-orange-500 to-orange-600' }
                    ].map(color => (
                      <label key={color.value} className="relative cursor-pointer">
                        <input
                          type="radio"
                          name="colors"
                          value={color.value}
                          checked={newSiteData.colors === color.value}
                          onChange={(e) => setNewSiteData(prev => ({ ...prev, colors: e.target.value }))}
                          className="sr-only"
                        />
                        <div className={`p-4 border-2 rounded-xl text-center transition-all duration-200 ${
                          newSiteData.colors === color.value
                            ? 'border-gray-400 ring-2 ring-gray-300'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}>
                          <div className={`w-12 h-12 bg-gradient-to-r ${color.gradient} rounded-lg mx-auto mb-2`}></div>
                          <span className="text-sm font-medium text-gray-700">{color.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-4 pt-6">
                  <button
                    type="button"
                    onClick={() => setShowCreateSiteModal(false)}
                    className="px-6 py-3 text-gray-700 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={isCreatingSite}
                    className="flex items-center space-x-2 bg-red-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isCreatingSite ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Création...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        <span>Créer le site</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;