import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Phone, MapPin, Clock, Star, ChefHat, Utensils } from 'lucide-react';

const RestaurantDemo = () => {
  const menuItems = [
    {
      category: "Entrées",
      items: [
        { name: "Salade César", description: "Salade romaine, parmesan, croûtons, sauce César", price: "12€" },
        { name: "Carpaccio de bœuf", description: "Fines lamelles de bœuf, roquette, parmesan", price: "16€" },
        { name: "Velouté de champignons", description: "Crème de champignons de saison, truffe", price: "10€" }
      ]
    },
    {
      category: "Plats",
      items: [
        { name: "Filet de bœuf", description: "Sauce au poivre, légumes de saison, pommes sarladaises", price: "28€" },
        { name: "Saumon grillé", description: "Risotto aux légumes, sauce hollandaise", price: "24€" },
        { name: "Risotto aux champignons", description: "Champignons de saison, parmesan, truffe", price: "20€" }
      ]
    },
    {
      category: "Desserts",
      items: [
        { name: "Tarte tatin", description: "Pommes caramélisées, glace vanille", price: "8€" },
        { name: "Tiramisu maison", description: "Mascarpone, café, cacao", price: "9€" },
        { name: "Fondant au chocolat", description: "Cœur coulant, glace vanille", price: "10€" }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50">
      {/* Navigation */}
      <nav className="bg-white/90 backdrop-blur-md border-b border-gray-200/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-2 rounded-lg">
                <ChefHat className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                Le Petit Bistrot
              </span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#menu" className="text-gray-700 hover:text-amber-600 font-medium transition-colors">Menu</a>
              <a href="#about" className="text-gray-700 hover:text-amber-600 font-medium transition-colors">À propos</a>
              <a href="#contact" className="text-gray-700 hover:text-amber-600 font-medium transition-colors">Contact</a>
              <button className="bg-amber-600 text-white px-6 py-2 rounded-lg hover:bg-amber-700 transition-colors font-medium">
                Réserver
              </button>
            </div>

            <Link
              to="/dashboard"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-amber-600/10 to-orange-600/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Bienvenue au{' '}
                <span className="bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                  Petit Bistrot
                </span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Une cuisine française authentique dans un cadre chaleureux. 
                Découvrez nos spécialités préparées avec des produits frais et locaux.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-amber-600 to-orange-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-200">
                  Réserver une table
                </button>
                <a
                  href="#menu"
                  className="text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg border-2 border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all duration-200 text-center"
                >
                  Voir le menu
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-3xl p-8 shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg"
                  alt="Restaurant interior"
                  className="w-full h-80 object-cover rounded-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-amber-100 text-amber-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Utensils className="h-4 w-4" />
              <span>Notre carte</span>
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Menu du jour
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Une sélection de plats préparés avec passion par notre chef
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {menuItems.map((category, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 shadow-lg border border-gray-100">
                <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                  {category.category}
                </h3>
                <div className="space-y-6">
                  {category.items.map((item, itemIndex) => (
                    <div key={itemIndex} className="border-b border-gray-200 pb-4 last:border-b-0">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-semibold text-gray-900">{item.name}</h4>
                        <span className="text-amber-600 font-bold">{item.price}</span>
                      </div>
                      <p className="text-gray-600 text-sm">{item.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Notre histoire
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Depuis 1985, Le Petit Bistrot vous accueille dans une ambiance conviviale 
                et authentique. Notre chef, formé dans les plus grandes maisons, 
                revisite la cuisine française traditionnelle avec créativité.
              </p>
              <div className="flex items-center space-x-4 mb-6">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <span className="text-gray-600">4.8/5 sur Google Reviews</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <div className="text-2xl font-bold text-amber-600">35+</div>
                  <div className="text-sm text-gray-600">Années d'expérience</div>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <div className="text-2xl font-bold text-amber-600">1000+</div>
                  <div className="text-sm text-gray-600">Clients satisfaits</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/887827/pexels-photo-887827.jpeg"
                alt="Chef cooking"
                className="w-full h-96 object-cover rounded-3xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Nous contacter</h2>
            <p className="text-xl text-gray-300">
              Réservez votre table ou contactez-nous pour plus d'informations
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-amber-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Téléphone</h3>
              <p className="text-gray-300">01 42 34 56 78</p>
            </div>

            <div className="text-center">
              <div className="bg-amber-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Adresse</h3>
              <p className="text-gray-300">123 Rue de la Paix<br />75001 Paris</p>
            </div>

            <div className="text-center">
              <div className="bg-amber-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Horaires</h3>
              <p className="text-gray-300">Mar-Dim: 12h-14h30<br />19h-22h30</p>
            </div>
          </div>

          <div className="text-center mt-12">
            <button className="bg-gradient-to-r from-amber-600 to-orange-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-200">
              Réserver maintenant
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-2 rounded-lg">
              <ChefHat className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold">Le Petit Bistrot</span>
          </div>
          <p className="text-gray-400">
            © 2024 Le Petit Bistrot. Tous droits réservés. | Site créé avec TovyoApp
          </p>
        </div>
      </footer>
    </div>
  );
};

export default RestaurantDemo;