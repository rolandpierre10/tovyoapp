import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Camera, Mail, Instagram, Facebook, Twitter, Award, Users, Heart } from 'lucide-react';

const PortfolioDemo = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'Tous' },
    { id: 'wedding', name: 'Mariages' },
    { id: 'portrait', name: 'Portraits' },
    { id: 'nature', name: 'Nature' },
    { id: 'event', name: 'Événements' }
  ];

  const portfolio = [
    {
      id: 1,
      category: 'wedding',
      title: 'Mariage Sarah & Thomas',
      image: 'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg',
      description: 'Une cérémonie magique en Provence'
    },
    {
      id: 2,
      category: 'portrait',
      title: 'Portrait Corporate',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
      description: 'Séance photo professionnelle'
    },
    {
      id: 3,
      category: 'nature',
      title: 'Coucher de soleil',
      image: 'https://images.pexels.com/photos/158251/forest-the-sun-morning-tucholskie-158251.jpeg',
      description: 'Paysage forestier au crépuscule'
    },
    {
      id: 4,
      category: 'wedding',
      title: 'Mariage Emma & Lucas',
      image: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg',
      description: 'Cérémonie intime au château'
    },
    {
      id: 5,
      category: 'portrait',
      title: 'Séance Famille',
      image: 'https://images.pexels.com/photos/1128318/pexels-photo-1128318.jpeg',
      description: 'Moments de complicité familiale'
    },
    {
      id: 6,
      category: 'event',
      title: 'Événement Corporate',
      image: 'https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg',
      description: 'Conférence d\'entreprise'
    }
  ];

  const filteredPortfolio = selectedCategory === 'all' 
    ? portfolio 
    : portfolio.filter(item => item.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-slate-50">
      {/* Navigation */}
      <nav className="bg-white/90 backdrop-blur-md border-b border-gray-200/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-gray-800 to-slate-700 p-2 rounded-lg">
                <Camera className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-gray-800 to-slate-700 bg-clip-text text-transparent">
                Marie Dubois
              </span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#portfolio" className="text-gray-700 hover:text-gray-900 font-medium transition-colors">Portfolio</a>
              <a href="#about" className="text-gray-700 hover:text-gray-900 font-medium transition-colors">À propos</a>
              <a href="#services" className="text-gray-700 hover:text-gray-900 font-medium transition-colors">Services</a>
              <a href="#contact" className="text-gray-700 hover:text-gray-900 font-medium transition-colors">Contact</a>
              <button className="bg-gray-800 text-white px-6 py-2 rounded-lg hover:bg-gray-900 transition-colors font-medium">
                Réserver
              </button>
            </div>

            <Link
              to="/dashboard"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/5 to-slate-900/5"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Photographe{' '}
                <span className="bg-gradient-to-r from-gray-800 to-slate-700 bg-clip-text text-transparent">
                  Professionnelle
                </span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Spécialisée dans les mariages, portraits et événements. 
                Je capture vos moments les plus précieux avec créativité et émotion.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <button className="bg-gradient-to-r from-gray-800 to-slate-700 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-200">
                  Voir mon portfolio
                </button>
                <a
                  href="#contact"
                  className="text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg border-2 border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all duration-200 text-center"
                >
                  Me contacter
                </a>
              </div>
              
              <div className="flex items-center space-x-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">500+</div>
                  <div className="text-sm text-gray-600">Mariages</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">8</div>
                  <div className="text-sm text-gray-600">Années d'expérience</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">100%</div>
                  <div className="text-sm text-gray-600">Clients satisfaits</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-gray-100 to-slate-100 rounded-3xl p-8 shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/1264210/pexels-photo-1264210.jpeg"
                  alt="Marie Dubois Photographer"
                  className="w-full h-80 object-cover rounded-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-gray-100 text-gray-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Camera className="h-4 w-4" />
              <span>Mon travail</span>
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Portfolio
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Une sélection de mes plus beaux clichés
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                  selectedCategory === category.id
                    ? 'bg-gray-800 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Portfolio Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPortfolio.map((item) => (
              <div
                key={item.id}
                className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-6 left-6 right-6 text-white">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-200">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1264210/pexels-photo-1264210.jpeg"
                alt="About Marie"
                className="w-full h-96 object-cover rounded-3xl shadow-2xl"
              />
            </div>
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                À propos de moi
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Passionnée de photographie depuis plus de 8 ans, je me spécialise 
                dans l'art de capturer les émotions authentiques. Chaque cliché 
                raconte une histoire unique que je m'efforce de préserver avec 
                sensibilité et créativité.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Diplômée de l'École Nationale de Photographie, j'ai eu l'honneur 
                de photographier plus de 500 mariages et événements à travers la France.
              </p>
              
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <Award className="h-8 w-8 text-gray-800 mx-auto mb-2" />
                  <div className="text-sm font-medium">Prix Excellence</div>
                  <div className="text-xs text-gray-600">2023</div>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <Users className="h-8 w-8 text-gray-800 mx-auto mb-2" />
                  <div className="text-sm font-medium">500+ Clients</div>
                  <div className="text-xs text-gray-600">Satisfaits</div>
                </div>
                <div className="text-center p-4 bg-white rounded-xl shadow-md">
                  <Heart className="h-8 w-8 text-gray-800 mx-auto mb-2" />
                  <div className="text-sm font-medium">Passion</div>
                  <div className="text-xs text-gray-600">Depuis 2016</div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
                  <Instagram className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
                  <Facebook className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
                  <Twitter className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Mes services
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Des prestations sur mesure pour tous vos événements
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Mariages',
                description: 'Reportage complet de votre jour J, de la préparation à la soirée',
                price: 'À partir de 1200€',
                features: ['Préparatifs', 'Cérémonie', 'Cocktail', 'Soirée', 'Galerie en ligne']
              },
              {
                title: 'Portraits',
                description: 'Séances photo individuelles, couple, famille ou corporate',
                price: 'À partir de 200€',
                features: ['1h de shooting', '20 photos retouchées', 'Galerie privée', 'Conseils styling']
              },
              {
                title: 'Événements',
                description: 'Couverture photo de vos événements professionnels ou privés',
                price: 'À partir de 400€',
                features: ['Reportage complet', 'Photos haute résolution', 'Livraison rapide', 'Usage commercial']
              }
            ].map((service, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-300">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <div className="text-2xl font-bold text-gray-800 mb-6">{service.price}</div>
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-600">
                      <div className="w-2 h-2 bg-gray-800 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-gray-800 text-white py-3 rounded-xl font-semibold hover:bg-gray-900 transition-colors">
                  Réserver
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Contactez-moi</h2>
            <p className="text-xl text-gray-300">
              Discutons de votre projet photo
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-6">Parlons de votre projet</h3>
              <p className="text-gray-300 mb-8">
                Chaque projet est unique. Contactez-moi pour discuter de vos besoins 
                et recevoir un devis personnalisé.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-gray-400" />
                  <span>marie.dubois@email.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Camera className="h-5 w-5 text-gray-400" />
                  <span>06 12 34 56 78</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-800 rounded-2xl p-8">
              <form className="space-y-6">
                <div>
                  <input
                    type="text"
                    placeholder="Votre nom"
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Votre email"
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <textarea
                    rows={4}
                    placeholder="Décrivez votre projet..."
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-gray-500 focus:border-transparent resize-none"
                  ></textarea>
                </div>
                <button className="w-full bg-white text-gray-900 py-3 rounded-xl font-semibold hover:bg-gray-100 transition-colors">
                  Envoyer le message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="bg-gradient-to-r from-gray-800 to-slate-700 p-2 rounded-lg">
              <Camera className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold">Marie Dubois</span>
          </div>
          <p className="text-gray-400">
            © 2024 Marie Dubois Photography. Tous droits réservés. | Site créé avec TovyoApp
          </p>
        </div>
      </footer>
    </div>
  );
};

export default PortfolioDemo;