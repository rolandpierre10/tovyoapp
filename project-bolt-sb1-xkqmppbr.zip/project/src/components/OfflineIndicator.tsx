import React from 'react';
import { WifiOff, Wifi } from 'lucide-react';
import { usePWA } from '../hooks/usePWA';

const OfflineIndicator: React.FC = () => {
  const { isOnline } = usePWA();
  const [showOfflineMessage, setShowOfflineMessage] = React.useState(false);
  const [wasOffline, setWasOffline] = React.useState(false);

  React.useEffect(() => {
    if (!isOnline) {
      setShowOfflineMessage(true);
      setWasOffline(true);
    } else if (wasOffline) {
      // Afficher brièvement le message de reconnexion
      setShowOfflineMessage(true);
      const timer = setTimeout(() => {
        setShowOfflineMessage(false);
        setWasOffline(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, wasOffline]);

  if (!showOfflineMessage) {
    return null;
  }

  return (
    <div className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 animate-slideDown`}>
      <div className={`rounded-xl px-4 py-3 shadow-lg border flex items-center space-x-3 ${
        isOnline 
          ? 'bg-green-50 border-green-200 text-green-800' 
          : 'bg-red-50 border-red-200 text-red-800'
      }`}>
        {isOnline ? (
          <>
            <Wifi className="h-5 w-5 text-green-600" />
            <span className="font-medium">Connexion rétablie</span>
          </>
        ) : (
          <>
            <WifiOff className="h-5 w-5 text-red-600" />
            <span className="font-medium">Mode hors ligne</span>
          </>
        )}
      </div>
    </div>
  );
};

export default OfflineIndicator;