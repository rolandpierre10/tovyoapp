import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Globe, ArrowLeft, Smartphone, RefreshCw, Download, Settings, Chrome, Variable as Safari, MoreHorizontal, Share, Home, Trash2, Plus, CheckCircle, AlertCircle, Info } from 'lucide-react';

const MobileUpdateGuide = () => {
  const [activeTab, setActiveTab] = useState('browser');

  const updateMethods = [
    {
      id: 'browser',
      title: 'Navigateur Web',
      icon: Globe,
      description: 'Mise à jour automatique dans le navigateur'
    },
    {
      id: 'pwa',
      title: 'Application Installée',
      icon: Smartphone,
      description: 'App installée sur l\'écran d\'accueil'
    },
    {
      id: 'manual',
      title: 'Mise à jour manuelle',
      icon: RefreshCw,
      description: 'Forcer la mise à jour'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                TovyoApp
              </span>
            </Link>
            
            <Link
              to="/"
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <RefreshCw className="h-8 w-8 text-blue-600" />
          </div>
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Mettre à jour sur mobile
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Guide complet pour mettre à jour TovyoApp sur votre appareil mobile
          </p>
        </div>

        {/* Method Tabs */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row bg-gray-100 rounded-2xl p-2 gap-2">
            {updateMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => setActiveTab(method.id)}
                className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl font-medium transition-all duration-200 ${
                  activeTab === method.id
                    ? 'bg-white text-blue-600 shadow-md'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <method.icon className="h-5 w-5" />
                <span className="hidden sm:inline">{method.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Browser Update */}
        {activeTab === 'browser' && (
          <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
            <div className="text-center mb-8">
              <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Mise à jour automatique</h2>
              <p className="text-gray-600">
                TovyoApp se met à jour automatiquement dans votre navigateur
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <h3 className="font-semibold text-blue-900 mb-3">✨ Mise à jour transparente</h3>
                <p className="text-blue-800 mb-4">
                  Lorsque vous utilisez TovyoApp dans votre navigateur mobile, les mises à jour 
                  se font automatiquement en arrière-plan.
                </p>
                <div className="space-y-2 text-sm text-blue-700">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Aucune action requise</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Mise à jour en temps réel</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Toujours la dernière version</span>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Chrome className="h-6 w-6 text-blue-600" />
                    <h4 className="font-semibold text-gray-900">Chrome / Edge</h4>
                  </div>
                  <ol className="space-y-2 text-sm text-gray-700">
                    <li>1. Ouvrez tovyoapp.com</li>
                    <li>2. La mise à jour se fait automatiquement</li>
                    <li>3. Rechargez la page si nécessaire</li>
                  </ol>
                </div>

                <div className="border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Safari className="h-6 w-6 text-gray-600" />
                    <h4 className="font-semibold text-gray-900">Safari</h4>
                  </div>
                  <ol className="space-y-2 text-sm text-gray-700">
                    <li>1. Visitez tovyoapp.com</li>
                    <li>2. Mise à jour automatique</li>
                    <li>3. Actualisez si besoin</li>
                  </ol>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <div className="flex items-start space-x-3">
                  <Info className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="text-yellow-800 text-sm">
                      <strong>Astuce :</strong> Si vous ne voyez pas les dernières fonctionnalités, 
                      actualisez la page en tirant vers le bas ou en appuyant sur le bouton de rechargement.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PWA Update */}
        {activeTab === 'pwa' && (
          <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
            <div className="text-center mb-8">
              <div className="bg-purple-100 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Smartphone className="h-6 w-6 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Application installée</h2>
              <p className="text-gray-600">
                Mise à jour de l'app installée sur votre écran d'accueil
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-purple-50 border border-purple-200 rounded-xl p-6">
                <h3 className="font-semibold text-purple-900 mb-3">📱 App Progressive Web</h3>
                <p className="text-purple-800 mb-4">
                  Si vous avez installé TovyoApp sur votre écran d'accueil, elle se met à jour 
                  automatiquement comme une app native.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="bg-green-100 p-2 rounded-lg">
                      <Download className="h-5 w-5 text-green-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900">Mise à jour automatique</h4>
                  </div>
                  <div className="space-y-3 text-sm text-gray-700">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Téléchargement en arrière-plan</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Installation automatique</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Notification de mise à jour</span>
                    </div>
                  </div>
                </div>

                <div className="border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <RefreshCw className="h-5 w-5 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900">Forcer la mise à jour</h4>
                  </div>
                  <ol className="space-y-2 text-sm text-gray-700">
                    <li>1. Fermez complètement l'app</li>
                    <li>2. Rouvrez l'app</li>
                    <li>3. La mise à jour s'applique</li>
                  </ol>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <h4 className="font-semibold text-blue-900 mb-3">🔄 Processus de mise à jour</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-blue-600 font-bold">1</span>
                    </div>
                    <p className="text-sm text-blue-800">Détection automatique</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-blue-600 font-bold">2</span>
                    </div>
                    <p className="text-sm text-blue-800">Téléchargement silencieux</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-blue-600 font-bold">3</span>
                    </div>
                    <p className="text-sm text-blue-800">Application au redémarrage</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Manual Update */}
        {activeTab === 'manual' && (
          <div className="bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
            <div className="text-center mb-8">
              <div className="bg-orange-100 w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Settings className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Mise à jour manuelle</h2>
              <p className="text-gray-600">
                Forcer la mise à jour si elle ne se fait pas automatiquement
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="h-5 w-5 text-orange-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-orange-900 mb-2">Quand utiliser cette méthode ?</h3>
                    <ul className="text-orange-800 text-sm space-y-1">
                      <li>• La mise à jour automatique ne fonctionne pas</li>
                      <li>• Vous voulez forcer une mise à jour immédiate</li>
                      <li>• L'app semble avoir des problèmes</li>
                      <li>• Vous ne voyez pas les nouvelles fonctionnalités</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Chrome className="h-6 w-6 text-blue-600" />
                    <h4 className="font-semibold text-gray-900">Chrome / Edge</h4>
                  </div>
                  <ol className="space-y-3 text-sm text-gray-700">
                    <li className="flex items-start space-x-2">
                      <span className="bg-blue-100 text-blue-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">1</span>
                      <span>Appuyez sur les 3 points <MoreHorizontal className="h-4 w-4 inline mx-1" /> en haut à droite</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="bg-blue-100 text-blue-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">2</span>
                      <span>Sélectionnez "Actualiser" <RefreshCw className="h-4 w-4 inline mx-1" /></span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="bg-blue-100 text-blue-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">3</span>
                      <span>Ou tirez vers le bas pour actualiser</span>
                    </li>
                  </ol>
                </div>

                <div className="border border-gray-200 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Safari className="h-6 w-6 text-gray-600" />
                    <h4 className="font-semibold text-gray-900">Safari</h4>
                  </div>
                  <ol className="space-y-3 text-sm text-gray-700">
                    <li className="flex items-start space-x-2">
                      <span className="bg-gray-100 text-gray-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">1</span>
                      <span>Appuyez sur <RefreshCw className="h-4 w-4 inline mx-1" /> dans la barre d'adresse</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="bg-gray-100 text-gray-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">2</span>
                      <span>Ou tirez vers le bas pour actualiser</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className="bg-gray-100 text-gray-600 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">3</span>
                      <span>Maintenez appuyé pour "Actualiser sans cache"</span>
                    </li>
                  </ol>
                </div>
              </div>

              <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                <h4 className="font-semibold text-red-900 mb-3">🚨 Méthode avancée : Vider le cache</h4>
                <p className="text-red-800 text-sm mb-4">
                  Si la mise à jour ne fonctionne toujours pas, vous pouvez vider le cache :
                </p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-medium text-red-900 mb-2">Chrome :</h5>
                    <ol className="text-xs text-red-700 space-y-1">
                      <li>1. Menu → Paramètres</li>
                      <li>2. Confidentialité et sécurité</li>
                      <li>3. Effacer les données de navigation</li>
                      <li>4. Sélectionner "tovyoapp.com"</li>
                    </ol>
                  </div>
                  <div>
                    <h5 className="font-medium text-red-900 mb-2">Safari :</h5>
                    <ol className="text-xs text-red-700 space-y-1">
                      <li>1. Réglages → Safari</li>
                      <li>2. Avancé → Données de sites web</li>
                      <li>3. Supprimer "tovyoapp.com"</li>
                      <li>4. Redémarrer Safari</li>
                    </ol>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                <h4 className="font-semibold text-green-900 mb-3">✅ Vérifier la mise à jour</h4>
                <p className="text-green-800 text-sm mb-3">
                  Après la mise à jour, vérifiez que vous avez la dernière version :
                </p>
                <ul className="text-green-700 text-sm space-y-1">
                  <li>• Nouvelles fonctionnalités visibles</li>
                  <li>• Interface mise à jour</li>
                  <li>• Performances améliorées</li>
                  <li>• Aucun message d'erreur</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* FAQ Section */}
        <div className="mt-16 bg-white rounded-3xl shadow-2xl shadow-gray-200/50 border border-gray-100 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Questions fréquentes</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">À quelle fréquence TovyoApp se met-il à jour ?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Les mises à jour sont déployées automatiquement dès qu'elles sont disponibles, 
                généralement plusieurs fois par semaine pour les améliorations mineures.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Mes données sont-elles conservées ?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Oui, toutes vos données (sites, paramètres, abonnement) sont conservées 
                lors des mises à jour. Elles sont stockées de manière sécurisée.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Que faire si la mise à jour échoue ?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Essayez de vider le cache de votre navigateur ou contactez notre support 
                si le problème persiste.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Comment savoir si j'ai la dernière version ?</h3>
              <p className="text-gray-600 text-sm mb-4">
                La version est automatiquement la plus récente. Si vous avez des doutes, 
                actualisez la page ou redémarrez l'application.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Support */}
        <div className="mt-8 text-center">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 inline-block">
            <h3 className="font-semibold text-blue-900 mb-2">Besoin d'aide ?</h3>
            <p className="text-blue-800 text-sm mb-4">
              Notre équipe support est là pour vous aider avec les mises à jour
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              <span>Contacter le support</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileUpdateGuide;