import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import LandingPage from './components/LandingPage';
import ThankYouPage from './components/ThankYouPage';
import CreateSitePage from './components/CreateSitePage';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import DashboardPage from './components/DashboardPage';
import PaymentPage from './components/PaymentPage';
import AdminLoginPage from './components/AdminLoginPage';
import AdminDashboard from './components/AdminDashboard';
import RestaurantDemo from './components/demos/RestaurantDemo';
import PortfolioDemo from './components/demos/PortfolioDemo';
import EcommerceDemo from './components/demos/EcommerceDemo';
import ContactPage from './components/LegalPages/ContactPage';
import TermsPage from './components/LegalPages/TermsPage';
import PrivacyPage from './components/LegalPages/PrivacyPage';
import CookiesPage from './components/LegalPages/CookiesPage';
import MobileUpdateGuide from './components/MobileUpdateGuide';
import PWAInstallPrompt from './components/PWAInstallPrompt';
import PWAUpdatePrompt from './components/PWAUpdatePrompt';
import OfflineIndicator from './components/OfflineIndicator';
import AuthTestPage from './components/AuthTestPage';

// Composant pour protéger les routes authentifiées
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/connexion" replace />;
  }
  
  // Si c'est un admin, rediriger vers le dashboard admin
  if (user.isAdmin) {
    return <Navigate to="/admin\" replace />;
  }
  
  return <>{children}</>;
};

// Composant pour protéger les routes admin
const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/admin/login" replace />;
  }
  
  if (!user.isAdmin) {
    return <Navigate to="/\" replace />;
  }
  
  return <>{children}</>;
};

// Composant pour protéger les routes qui nécessitent un abonnement
const SubscriptionRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/connexion" replace />;
  }
  
  // Si c'est un admin, rediriger vers le dashboard admin
  if (user.isAdmin) {
    return <Navigate to="/admin\" replace />;
  }
  
  if (!user.hasActiveSubscription) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return <>{children}</>;
};

// Composant pour rediriger les utilisateurs connectés
const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <>{children}</>;
  }
  
  // Si l'utilisateur est admin, rediriger vers le dashboard admin
  if (user.isAdmin) {
    return <Navigate to="/admin" replace />;
  }
  
  // Si l'utilisateur normal est connecté, rediriger vers le dashboard
  return <Navigate to="/dashboard" replace />;
};

function AppContent() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* PWA Components */}
      <PWAInstallPrompt />
      <PWAUpdatePrompt />
      <OfflineIndicator />
      
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route 
          path="/connexion" 
          element={
            <PublicRoute>
              <LoginPage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/inscription" 
          element={
            <PublicRoute>
              <RegisterPage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/paiement" 
          element={
            <ProtectedRoute>
              <PaymentPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/formulaire" 
          element={
            <SubscriptionRoute>
              <CreateSitePage />
            </SubscriptionRoute>
          } 
        />
        <Route 
          path="/merci" 
          element={
            <SubscriptionRoute>
              <ThankYouPage />
            </SubscriptionRoute>
          } 
        />
        
        {/* Admin Routes */}
        <Route 
          path="/admin/login" 
          element={
            <PublicRoute>
              <AdminLoginPage />
            </PublicRoute>
          } 
        />
        <Route 
          path="/admin" 
          element={
            <AdminRoute>
              <AdminDashboard />
            </AdminRoute>
          } 
        />
        
        {/* Demo Routes */}
        <Route path="/demo/restaurant-demo" element={<RestaurantDemo />} />
        <Route path="/demo/portfolio-demo" element={<PortfolioDemo />} />
        <Route path="/demo/ecommerce-demo" element={<EcommerceDemo />} />
        <Route path="/demo/test-ecommerce" element={<EcommerceDemo />} />
        
        {/* Legal Pages */}
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/conditions" element={<TermsPage />} />
        <Route path="/confidentialite" element={<PrivacyPage />} />
        <Route path="/cookies" element={<CookiesPage />} />
        
        {/* Help Pages */}
        <Route path="/aide/mise-a-jour-mobile" element={<MobileUpdateGuide />} />
        
        {/* Test Page */}
        <Route path="/test-auth" element={<AuthTestPage />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <Router>
          <AppContent />
        </Router>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;